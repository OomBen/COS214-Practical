#include "CargoDragon.h"

CargoDragon::CargoDragon(Component* r): RocketCapsule(r)
{
	this->capsuleType = "Cargo Dragon";
}

void CargoDragon::simulate() 
{
	//Might need to add more stuff to output here
	cout << capsuleType << " State: " << getState() << endl;
}

void CargoDragon::test() 
{
	// TODO - implement CargoDragon::test
	throw "Not yet implemented";
}
