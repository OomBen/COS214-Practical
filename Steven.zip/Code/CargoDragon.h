#ifndef CARGODRAGON_H
#define CARGODRAGON_H

#include "RocketCapsule.h"

class CargoDragon : public RocketCapsule 
{
	public:
		CargoDragon(Component*);
		void simulate();
		void test();
};

#endif
