#include "Online.h"

Online::Online(){}

string Online::getType() {
	return "Online";
}
