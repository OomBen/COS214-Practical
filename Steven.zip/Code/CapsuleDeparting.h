#ifndef CAPSULEDEPARTING_H
#define CAPSULEDEPARTING_H

#include "CapsuleState.h"

class CapsuleDeparting : public CapsuleState 
{
	public:
		CapsuleDeparting();
		string getState();
};

#endif
