#ifndef FALCON9CONCRETEHANDLER_H
#define FALCON9CONCRETEHANDLER_H

#include "ComponentComposite.h"

class Falcon9ConcreteHandler
{
	public:
		void handleStagingRequest();
};

#endif
