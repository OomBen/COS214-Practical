#include "CapsuleDocked.h"

CapsuleDocked::CapsuleDocked(){}
string CapsuleDocked::getState(){}
