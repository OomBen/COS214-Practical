#ifndef CAPSULEARRIVING_H
#define CAPSULEARRIVING_H

#include "CapsuleState.h"

using namespace std;
class CapsuleArriving : public CapsuleState 
{
	public:
		CapsuleArriving();
		string getState();
};

#endif
