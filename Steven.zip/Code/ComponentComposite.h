#ifndef COMPONENTCOMPOSITE_H
#define COMPONENTCOMPOSITE_H

#include "Component.h"
#include <vector>

class ComponentComposite : public Component 
{
	private:
		vector<Component*> components;

	public:
		ComponentComposite();
		void simulate();
		void test();
		void add(Component* c);
		void remove(int pos);
		Component* getComponent(int pos);
		virtual void handleStagingRequest();
};

#endif
