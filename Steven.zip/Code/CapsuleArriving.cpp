#include "CapsuleArriving.h"

CapsuleArriving::CapsuleArriving(){}
string CapsuleArriving::getState(){}


