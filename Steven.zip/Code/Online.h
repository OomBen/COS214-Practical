#ifndef ONLINE_H
#define ONLINE_H

#include "SatelliteState.h"

using namespace std;
class Online : public SatelliteState 
{
	public:
		Online();
		string getType();
};

#endif
