#include "CapsuleOffline.h"

CapsuleOffline::CapsuleOffline(){}
string CapsuleOffline::getState(){}


