#include "Offline.h"

Offline::Offline(){}

string Offline::getType() 
{
	return "Offline";
}
