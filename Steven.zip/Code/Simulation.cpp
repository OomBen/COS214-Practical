#include "Simulation.h"

Simulation::Simulation(Component* c) {
	// TODO - implement Simulation::Simulation
	throw "Not yet implemented";
}

void Simulation::staticFireTest() {
	// TODO - implement Simulation::staticFireTest
	throw "Not yet implemented";
}

void Simulation::launch() {
	// TODO - implement Simulation::launch
	throw "Not yet implemented";
}
