#include "MerlinEngine.h"

MerlinEngine::MerlinEngine(): Component(300000.0)
{

}

void MerlinEngine::simulate() 
{
	// TODO - implement MerlinEngine ::simulate
	throw "Not yet implemented";
}

void MerlinEngine::test() {
	// TODO - implement MerlinEngine ::test
	throw "Not yet implemented";
}
