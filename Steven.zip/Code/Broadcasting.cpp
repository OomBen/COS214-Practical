#include "Broadcasting.h"

Broadcasting::Broadcasting(){}

string Broadcasting::getType() 
{
	return "Broadcasting";
}

// void RedState::handleChange(Context* c) {
//     c->setState(new GreenState());
// }