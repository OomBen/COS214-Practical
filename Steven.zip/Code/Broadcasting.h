#ifndef BROADCASTING_H
#define BROADCASTING_H

#include "SatelliteState.h"

using namespace std;
class Broadcasting : public SatelliteState 
{
	public:
		Broadcasting();
		string getType();
};

#endif
