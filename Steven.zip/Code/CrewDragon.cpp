#include "CrewDragon.h"

CrewDragon::CrewDragon(Component* r): RocketCapsule(r)
{
	this->capsuleType = "Crew Dragon";
}

void CrewDragon::simulate() 
{
	//Might need to add more stuff to output here
	cout << capsuleType << " State: " << getState() << endl;
}

void CrewDragon::test() 
{
	// TODO - implement CrewDragon::test
	throw "Not yet implemented";
}

string* CrewDragon::getPassengers() 
{
	return passengers;
}
