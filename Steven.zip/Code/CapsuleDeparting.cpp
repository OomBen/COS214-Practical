#include "CapsuleDeparting.h"

CapsuleDeparting::CapsuleDeparting(){}
string CapsuleDeparting::getState(){}

