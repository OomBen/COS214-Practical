#ifndef CAPSULESTATE_H
#define CAPSULESTATE_H

#include <iostream>
#include <string>

using namespace std;
class CapsuleState 
{
	public:
		virtual string getState() = 0;
};

#endif
