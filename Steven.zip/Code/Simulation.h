#ifndef SIMULATION_H
#define SIMULATION_H

#include "SimulationState.h"
#include "Component.h"

class Simulation {

private:
	SimulationState* simulationSate;
	Component* component;

public:
	Simulation(Component* c);

	void staticFireTest();

	void launch();

	virtual void tweakSimulation() = 0;
};

#endif
