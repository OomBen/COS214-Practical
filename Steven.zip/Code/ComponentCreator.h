#ifndef COMPONENTCREATOR_H
#define COMPONENTCREATOR_H

#include "Component.h"

//Factory Method Creator: Abstract, not much to implement here
class ComponentCreator 
{
	private:
		Component* component;

	public:
		virtual Component* factoryMethod() = 0;
		virtual Component* clone(Component* C) = 0;
};

#endif
