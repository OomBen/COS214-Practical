#ifndef MEMENTO_H
#define MEMENTO_H

#include <iostream>
#include <string>

#include "SimulationState.h"

using namespace std;

class Memento 
{
	private:
		SimulationState* state;

	public:
		SimulationState* getState();
		void setState(SimulationState* c);
		~Memento();
};

#endif
