#include "Memento.h"

SimulationState* Memento::getState() {
	return this->state;
}

void Memento::setState(SimulationState* c) {
	this->state = c;
}
