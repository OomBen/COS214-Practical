#include "Director.h"

Director::Director(Builder* b) 
{
	this->builder = b;
}

Component* Director::construct() 
{
	string input = "";
	do {
		cout<<"What kind of rocket would you like to build?\n1: Falcon 9\n2: Falcon Heavy\n";
		cin>>input;
	} while (input!="1" &&input!= "2");
	if (input=="1") {
		cout<<"Creating a Falcon 9...\n";
		builder->buildFalcon9();
	} else {
		cout<<"Creating a Falcon Heavy...\n";
		builder->buildFalconHeavy();
	}

	input = "";
	do {
		cout<<"Would you like to add a capsule?\n1: Yes\n2: No\n";
		cin>>input;
		if (input == "1") {
			constructCapsule();
		}
	} while (input!= "2");

	return this->builder->getSpacecraft();
}

void Director::constructCapsule() {
	string input = "";
	do {
		cout<<"What kind of capsule would you like to build?\n1: Crew Dragon\n2: Cargo Dragon\n3: Fairing (You must have a Falcon 9 in order to build a fairing)\n";
		cin>>input;
	} while (input!="1" &&input!= "2"&&input!="3");
	if (input=="1") {
		cout<<"Creating a Crew Dragon...\n";
		builder->constructCapsule("Crew Dragon");
	} else if (input=="2") {
		cout<<"Creating a Cargo Dragon...\n";
		builder->constructCapsule("Cargo Dragon");
	} else {
		//must be a Falcon 9
		cout<<"Creating a Fairing...\n";
		builder->constructCapsule("Fairing");
	}
}

