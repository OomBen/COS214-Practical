#ifndef OFFLINE_H
#define OFFLINE_H

#include "SatelliteState.h"

using namespace std;
class Offline: public SatelliteState 
{
	public:
		Offline();
		string getType();
};

#endif
