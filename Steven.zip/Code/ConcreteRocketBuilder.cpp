#include "ConcreteRocketBuilder.h"

ConcreteRocketBuilder::ConcreteRocketBuilder(){
    merlinCreator = new MerlinEngineCreator();
    vacuumMerlinCreator = new VacuumMerlinEngineCreator();
    coreCreator = new CoreCreator();
    rocket = new ComponentComposite();
    capsule = NULL;
}

Component* ConcreteRocketBuilder::getSpacecraft() {
    return this->capsule;
}

void ConcreteRocketBuilder::buildFalcon9() {
	Component* core = coreCreator -> factoryMethod();

    Component* merlinEngines = new ComponentComposite();
    for(int i = 0; i < 27; i++){
        merlinEngines -> add(merlinCreator -> factoryMethod());
    }

    Component* vacuumMerlin = vacuumMerlinCreator -> factoryMethod();

    rocket -> add(core);
    rocket -> add(merlinEngines);
    rocket -> add(vacuumMerlin);
}

void ConcreteRocketBuilder::buildFalconHeavy() {
    Component* cores = new ComponentComposite();
    for(int i = 0; i < 3; i++){
        cores -> add(coreCreator -> factoryMethod());
    }

    Component* merlinEngines = new ComponentComposite();
    for(int i = 0; i < 27; i++){
        merlinEngines -> add(merlinCreator -> factoryMethod());
    }

    Component* vacuumMerlin = vacuumMerlinCreator -> factoryMethod();

    rocket -> add(cores);
    rocket -> add(merlinEngines);
    rocket -> add(vacuumMerlin);
}

void ConcreteRocketBuilder::constructCapsule(string type){
    if(type == "Crew Dragon"){
        capsule = new CrewDragon(rocket);
    }
    else if(type == "Cargo Dragon"){
        capsule = new CargoDragon(rocket);
    }
    else if(type == "Fairing"){
        capsule = new Fairing(rocket);
    }
}