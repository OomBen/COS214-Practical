#include "Online.h"
#include "Broadcasting.h"

Online::Online(){}

string Online::getType() {
	return "Online";
}

void Online::handleChange(Satellite* s){
	s->setState(new Broadcasting());
}