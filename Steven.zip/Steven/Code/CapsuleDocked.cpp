#include "CapsuleDocked.h"
#include "CapsuleOffline.h"
#include "CapsuleState.h"
#include "RocketCapsule.h"

CapsuleDocked::CapsuleDocked(){}

string CapsuleDocked::getState()
{
    return "Docked";
}

void CapsuleDocked::handleChange(RocketCapsule* c)
{
    c->setState(new CapsuleOffline());
}