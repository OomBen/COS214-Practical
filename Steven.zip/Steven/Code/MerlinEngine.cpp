#include "MerlinEngine.h"

MerlinEngine::MerlinEngine(): Component(300000.0)
{

}

void MerlinEngine::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Merlin Engine | Status: Firing up | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void MerlinEngine::test() 
{
	string result = this->cost > 0 ? "Pass" : "Fail";
	cout << "Cost Test: " << result << endl;

	result = this->capsuleType != "" ? "Pass" : "Fail";
	cout << "Capsule Test: " << result << endl;

	result = this->rocketType != "" ? "Pass" : "Fail";
	cout << "Rocket Test: " << result << endl;
	//Ternary form equivalent of the statement
	// if(this->cost > 0)
	// {
	// 	string result = "Pass";
	// }
	// else
	// {
	// 	string result = "Fail";
	// }
}
