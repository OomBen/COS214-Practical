/**
	@file Broadcas
*/


#ifndef BROADCASTING_H
#define BROADCASTING_H

#include "SatelliteState.h"

using namespace std;
class Satellite;
class Broadcasting : public SatelliteState 
{
	public:
		Broadcasting();
		string getType();
		void handleChange(Satellite* s);
};

#endif
