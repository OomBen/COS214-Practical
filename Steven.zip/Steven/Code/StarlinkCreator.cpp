#include "StarlinkCreator.h"

Satellite* StarlinkCreator::factoryMethod() {
	return new StarlinkSatellite();
}
