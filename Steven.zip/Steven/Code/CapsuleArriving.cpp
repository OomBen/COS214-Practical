#include "CapsuleArriving.h"
#include "CapsuleDocked.h"

CapsuleArriving::CapsuleArriving(){}

string CapsuleArriving::getState(){
    return "Arriving";
}

void CapsuleArriving::handleChange(RocketCapsule* c){
    c->setState(new CapsuleDocked());
}

