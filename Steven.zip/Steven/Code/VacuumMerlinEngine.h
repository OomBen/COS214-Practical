#ifndef VACUUMMERLINENGINE_H
#define VACUUMMERLINENGINE_H

#include "Component.h"

class VacuumMerlinEngine : public Component
{
	public:
		VacuumMerlinEngine();
		void simulate();
		void test();
};

#endif
