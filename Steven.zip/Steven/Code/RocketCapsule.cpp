#include "RocketCapsule.h"
#include "CapsuleStateHierarchy.h"

RocketCapsule::RocketCapsule(Component* r): Component(0)
{
	rocket = r;
	state = new CapsuleOffline();
}

void RocketCapsule::simulate() 
{
	rocketCost += this->cost;
	cout << "Component Name: RocketCapsule | Status: Nominal | Component Cost:" << this->cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void RocketCapsule::test() 
{
	string result = this->cost > 0 ? "Pass" : "Fail";
	cout << "Cost Test: " << result << endl;

	string result = this->capsuleType != "" ? "Pass" : "Fail";
	cout << "Capsule Test: " << result << endl;

	string result = this->rocketType != "" ? "Pass" : "Fail";
	cout << "Rocket Test: " << result << endl;
	//Ternary form equivalent of the statement
	// if(this->cost > 0)
	// {
	// 	string result = "Pass";
	// }
	// else
	// {
	// 	string result = "Fail";
	// }
}

void RocketCapsule::addCapsule(Component* r)
{
	//Register this to an existing component
	rocket = r;
}

void RocketCapsule::changeState() 
{
	
}

// CapsuleState* RocketCapsule::getState()
// {
//     return state;
// }

void RocketCapsule::setState(CapsuleState* s){
	delete state;
	state = s;
}

double RocketCapsule::getPayloadWeight() 
{
	return payloadWeight;
}

void RocketCapsule::setPayloadWeight(double pw) 
{
	payloadWeight = pw;
}

void RocketCapsule::requestStateChange(){
	state->handleChange(this);
}
