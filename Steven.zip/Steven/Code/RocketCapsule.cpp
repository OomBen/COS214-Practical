#include "RocketCapsule.h"

RocketCapsule::RocketCapsule(Component* r): Component(0)
{
	rocket = r;
	state = new CapsuleOffline();
}

void RocketCapsule::simulate() 
{
	//Any suggestions here would be nice. This is the basae class though, so it doesn't have to be tooooo specific
	cout << capsuleType << " State: " << state->getState() << endl;
}

void RocketCapsule::test() 
{
	//TODO
}

void RocketCapsule::addCapsule(Component* r)
{
	//Register this to an existing component
	rocket = r;
}

void RocketCapsule::changeState() 
{
	
}

CapsuleState* RocketCapsule::getState()
{
    return state;
}

void RocketCapsule::setState(CapsuleState* s){
	delete state;
	state = s
}

double RocketCapsule::getPayloadWeight() 
{
	return this->payloadweight;
}

void RocketCapsule::setPayloadWeight(double pw) 
{
	this->payloadweight = pw;
}

void RocketCapsule::requestStateChange(){
	state->handleChange(this);
}
