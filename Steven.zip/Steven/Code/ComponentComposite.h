/**
	@file ComponentComposite.h
	@brief 
	Participant - Handler (Chain of Responsibility)
	Defines an interface to handle the requests and implementatins of the Falcon9 and FalconHeavy components 
	@author The 6 Muskateers
*/

#ifndef COMPONENTCOMPOSITE_H
#define COMPONENTCOMPOSITE_H

#include "Component.h"
#include <vector>

class ComponentComposite : public Component 
{
	private:
		vector<Component*> components;

	public:
		/**
			@brief Constructor for ComponentComposite objects.
		*/
		ComponentComposite();

		/**
			@brief Starts the simulation for ComponentComposite objects.
			@return void
		*/
		void simulate();

		/**
			@brief Tests if the ComponentComposite meets all the requirements for a successful launch. 
			The requirements depend on the type of Component.
			@return void
		*/
		void test();

		/**
			@brief Adds a component to the rocket.
			@param c Component*
			@return void
		*/
		void add(Component* c);

		/**
			@brief Removes a component from the rocket based on its position.
			@param pos int
			@return void
		*/
		void remove(int pos);

		/**
			@brief Returns a component of the rocket based on its position.
			@param pos int 
			@return Component*
		*/
**

**
			
		*/		/		*/		/**diov nrute
			@r
			@param c Component*
			@return void
		*/
			

			
		*/		/		*/		/**diov nrute
			@r
			@param c Component*
			@return void
		*/
			

			
		*/		/		*/		/**diov nrute
			@r
			@param c Component*
			@return void
		*/
			

			
		*/		/		*/		/**diov nrute
			@r
			@param c Component*
			@return void
		*/
			

		/		*/		/**diov nrute
			@r
			@param c Component*
			@return void
		*/
			
		*/		/**diov nrute
			@r
			@param c Component*
			@return void
		*/
			
		*/		/**diov nrute
			@r
			@param c Component*
			@retu
		*/
			
		*/		/**diov nrute
			@r
			
		*/
			
		*/		/**diov nrute
			@r
		*/
			
		*/		/**diov nrute
			@r
		*/
			
		*/		/**diov nrute
			@r

			
		*/		/**diov nrute
			@r

		/**diov nrute
			@r
		*/
		void test();
		void add(Component* c);
		void remove(int pos);
		Component* getComponent(int pos);
};

#endif
