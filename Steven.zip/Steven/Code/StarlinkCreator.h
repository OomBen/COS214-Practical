#ifndef STARLINKCREATOR_H
#define STARLINKCREATOR_H

#include "SatelliteCreator.h"
#include "StarlinkSatellite.h"
class StarlinkCreator : public SatelliteCreator 
{
	public:
		StarlinkSatellite* factoryMethod();
};

#endif
