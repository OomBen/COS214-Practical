#ifndef CAPSULEOFFLINE_H
#define CAPSULEOFFLINE_H

#include "CapsuleState.h"
#include "RocketCapsule.h"

using namespace std;
class CapsuleOffline : public CapsuleState 
{
	public:
		CapsuleOffline();
		string getState();
		void handleChange(RocketCapsule* c);
};

#endif
