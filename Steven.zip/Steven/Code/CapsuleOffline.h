/**
	@file CapsuleOffline.h
	@brief	
		Participant - Concrete State (State)
		Describes the methods of a Capusle that is in a 'docked' state.
	@author The 6 Musakteers
*/

#ifndef CAPSULEOFFLINE_H
#define CAPSULEOFFLINE_H

#include "CapsuleState.h"
#include "RocketCapsule.h"

using namespace std;
class CapsuleOffline : public CapsuleState 
{
	public:
		/**
			@brief Constructor for CapsuleOffline objects.
		*/
		CapsuleOffline();

		/**
			@brief Returns the state that the capsule is currently in (Offline).
			@return string
		*/
		string getState();

		/**
			@brief Handles a change in state - sets the state of the current capsule to 'null'.
			@param c RocketCapsule*
			@return void
		*/
		void handleChange(RocketCapsule* c);
};

#endif
