#include "FalconCore.h"

FalconCore::FalconCore(): Component(30000000.0)
{

}

void FalconCore::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Falcon Core | Status: Firing up | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void FalconCore::test() 
{
	string result = this->cost > 0 ? "Pass" : "Fail";
	cout << "Cost Test: " << result << endl;

	result = this->capsuleType != "" ? "Pass" : "Fail";
	cout << "Capsule Test: " << result << endl;

	result = this->rocketType != "" ? "Pass" : "Fail";
	cout << "Rocket Test: " << result << endl;
	//Ternary form equivalent of the statement
	// if(this->cost > 0)
	// {
	// 	string result = "Pass";
	// }
	// else
	// {
	// 	string result = "Fail";
	// }
}
