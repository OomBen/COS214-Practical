#ifndef CAPSULEDOCKED_H
#define CAPSULEDOCKED_H
 
#include "CapsuleState.h"

using namespace std;
class CapsuleDocked : public CapsuleState 
{
	public:
		CapsuleDocked();
		string getState();
		void handleChange(RocketCapsule* c);
};

#endif
