#include "Director.h"
#include "Builder.h"
#include "Simulation.h"
#include "ConcreteRocketBuilder.h"
#include "Caretaker.h"

//#include "unitTest.cpp"
//#include <gtest/gtest.h>

#include <stdio.h>
#include <unistd.h> // for usleep function

using namespace std;

const char rocket[] =
"           _\n\
          /^\\\n\
          |-|\n\
          | |\n\
          |S|\n\
          |P|\n\
          |A|\n\
          |C|\n\
          |E|\n\
          | |\n\
          |X|\n\
         /| |\\\n\
        / | | \\\n\
       |  | |  |\n\
        `-\"\"\"-`\n\
";


int main(int argc, char **argv) {
    //“critical”, “major”, “minor”, or “clear”

    //testing::InitGoogleTest(&argc, argv);
    //return RUN_ALL_TESTS();

    for (int i = 0; i < 50; i ++) printf("\n"); // jump to bottom of console
    printf("%s", rocket);
    int j = 300000;
    for (int i = 0; i < 50; i ++) {
        usleep(j);                  // move faster and faster,
        j = (int)(j * 0.9);         // so sleep less each time
        printf("\n          | |");  // move rocket a line upward
    }
    printf("\n");

    Builder * build = new ConcreteRocketBuilder();
    Director * direct = new Director (build);
    Simulation * simulate;

    direct->construct();
    direct->constructCapsule();
    simulate = direct->createSimulation();

    //simulate


    //Memento
    Caretaker store;
    store.storeMemento(simulate->createMemento());

        //do things then restore simulation using Memento

    simulate->restoreMemento(store.retrieveMemento());

}

