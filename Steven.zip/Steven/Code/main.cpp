#include "Director.h"
#include "Builder.h"
#include "Component.h"
#include "Simulation.h"

//#include "unitTest.cpp"
//#include <gtest/gtest.h>

using namespace std;

int main(int argc, char **argv) {
    //“critical”, “major”, “minor”, or “clear”

    //testing::InitGoogleTest(&argc, argv);
    //return RUN_ALL_TESTS();

}