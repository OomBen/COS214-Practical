#include "Offline.h"
#include "Online.h"

Offline::Offline(){}

string Offline::getType() 
{
	return "Offline";
}

void Offline::handleChange(Satellite* s)
{
	s->setState(new Online());
}