#ifndef CAPSULEARRIVING_H
#define CAPSULEARRIVING_H


using namespace std;

class CapsuleState;
class RocketCapsule;
class CapsuleArriving : public CapsuleState 
{
	public:
		CapsuleArriving();
		string getState();
		void handleChange(RocketCapsule* c)
};

#endif
