/**
	@file CapsuleArriving.h
	@brief	
		Participant - Concrete State (State)
		Describes the methods of a Capusle that is in an 'arriving' state.
	@author The 6 Musakteers
*/

#ifndef CAPSULEARRIVING_H
#define CAPSULEARRIVING_H

#include <string>

using namespace std;

//class CapsuleState;
class RocketCapsule;
class CapsuleDocked;

class CapsuleArriving : public CapsuleState 
{
	public:
		/**
			@brief Constructor for CapsuleArriving objects.
		*/
		CapsuleArriving();

		/**
			@brief Returns the state that the capsule is currently in (Arriving).
			@return string
		*/
		string getState();

		/**
			@brief Handles a change in state - sets the state of the current capsule to 'docked'.
			@param c RocketCapsule*
			@return void
		*/
		void handleChange(RocketCapsule* c);
};

#endif
