#ifndef FALCONCORE_H
#define FALCONCORE_H

#include "Component.h"

class FalconCore : public Component 
{
	public:
		FalconCore();
		void simulate();
		void test();
};

#endif
