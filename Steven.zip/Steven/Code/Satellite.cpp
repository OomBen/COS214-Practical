#include "Satellite.h"

//void Satellite::setState(State* s) {
//	// TODO - implement Satellite::setState
//	throw "Not yet implemented";
//}

Satellite::Satellite(int ID)
{
	this->ID = ID;
	satelliteState = new Offline();	//initialize state
}

//destruct observers (users), destruct SatelliteState
Satellite::~Satellite()
{
    vector<Observer*>::iterator it;
    for(it = observerList.begin(); it != observerList.end(); ++it) 
    {
        if((*it) != NULL)
        {
            delete (*it);
        }
    }

	if(satelliteState != NULL){
		delete satelliteState;
	}
}

//let mediator know of change
void Satellite::changed() {
	mediator->notify(this);
}

//Mediator* Satellite::getMediator() {
//	return this->mediator;
//}

int Satellite::getID()
{
	return ID;
}

//print out the state and ID of the changed colleague
void receiveStateInfo(string msg)
{
	cout << msg << endl;
}

void Satellite::setMediator(Mediator* m) {
	this->mediator = m;
}

//change state of satellite, then let mediator know, and let observers know
void Satellite::requestStateChange() {
	satelliteState->handleChange(this);
	changed();
	notify();
}

//register an observer with the satellite (subject)
void Satellite::attach(Observer* o) {
	observerList.push_back(o);	
}

//deregister an observer with this subject
void Satellite::detach(Observer* o) {
	bool found = false;

	vector<Observer*>::iterator it = observerList.begin();
	while ((it != observerList.end()) && (! found)) {
		if (*it == o) {
			found = true;
			observerList.erase(it);
		}
		++it;
	}
}

//notify all observers
void Satellite::notify() {
	vector<Observer*>::iterator it = observerList.begin();
	while ((it != observerList.end())) {
		(*it)->update();
		++it;
	}
}

SatelliteState* Satellite::getState(){
	return satelliteState;
}

void Satellite::setState(SatelliteState* s){
	delete satelliteState;
	satelliteState = s;
}
