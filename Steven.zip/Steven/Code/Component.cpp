#include "Component.h"

Component::Component(double c){
	cost = c;
}

void Component::add(Component* c) 
{
	//Virtual Function: called by inheriting composite
}

void Component::remove(int pos) 
{
	//Virtual Function: called by inheriting composite
}

Component* Component::getComponent(int pos) 
{
	//Virtual Function: called by inheriting composite
}

Component* Component::clone() 
{
	Component* newClone = new Component();
	newClone->cost = this->cost;
	newClone->rocketType = this->rocketType;
	newClone->capsuleType = this->capsuleType;
	return newClone;
}

double Component::getCost() 
{
	return cost;
}
