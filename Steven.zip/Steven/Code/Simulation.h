#ifndef SIMULATION_H
#define SIMULATION_H

#include "SimulationState.h"
#include "Component.h"
#include "Memento.h"

class Simulation {

private:
	SimulationState* simulationSate;
	Component* rocket;
	Component* capsule;

public:
	Simulation(Component* c,Component* r, SimulationState* s);

	Memento* createMemento();

	Memento* restoreMemento(Memento*);

	void staticFireTest();

	void launch();

	virtual void tweakSimulation() = 0;
};

#endif
