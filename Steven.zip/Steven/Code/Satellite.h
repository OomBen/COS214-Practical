#ifndef SATELLITE_H
#define SATELLITE_H

#include <iostream>
#include <vector>

#include "Mediator.h"
#include "Observer.h"
#include "Offline.h"

using namespace std;
class Mediator;
class SatelliteState;

class Satellite 
{
	protected:
		SatelliteState* satelliteState;
	private:
		Mediator* mediator;
		vector<Observer*> observerList;
		int ID;

	public:
		Satellite(int ID);
		~Satellite();
		void changed();
		//Mediator* getMediator();
		int getID();
		void receiveStateInfo(string msg);
		void setMediator(Mediator* m);
//		void requestStateChange();
		void attach(Observer* o);
		void detach(Observer* o);
		void notify();
		virtual SatelliteState* getState();
		void setState(SatelliteState* s);
};

#endif
