#include "SatelliteStateHierarchy.h"

Broadcasting::Broadcasting(){}

string Broadcasting::getType() 
{
	return "Broadcasting";
}

void Broadcasting::handleChange(Satellite* s)
{
	s->setState(new Offline());
}

Offline::Offline(){}

string Offline::getType() 
{
	return "Offline";
}

void Offline::handleChange(Satellite* s)
{
	s->setState(new Online());
}

Online::Online(){}

string Online::getType() {
	return "Online";
}

void Online::handleChange(Satellite* s){
	s->setState(new Broadcasting());
}