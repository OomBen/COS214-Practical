#ifndef CONCRETEROCKETBUILDER_H
#define CONCRETEROCKETBUILDER_H

#include "Builder.h"
#include "ComponentCreator.h"
#include "CoreCreator.h"
#include "VacuumMerlinEngineCreator.h"
#include "MerlinEngineCreator.h"
#include "ComponentComposite.h"
#include "RocketCapsule.h"
#include "CrewDragon.h"
#include "CargoDragon.h"
#include "Fairing.h"
#include "SimulationState.h"
#include "SatelliteCreator.h"
#include "StarlinkCreator.h"

#include <iostream>
#include <string>

class ConcreteRocketBuilder : public Builder 
{
	private:
		ComponentCreator* merlinCreator;
		ComponentCreator* vacuumMerlinCreator;
		ComponentCreator* coreCreator;
		Component* rocket;
		RocketCapsule* capsule;
		SimulationState* simulationState;

	public:
		ConcreteRocketBuilder();
		Component* getSpacecraft();
		void buildFalcon9();
		void buildFalconHeavy();
		void constructCapsule(string type);
		Simulation* createSimulation();
};

#endif
