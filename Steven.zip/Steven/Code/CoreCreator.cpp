#include "CoreCreator.h"

Component* CoreCreator::factoryMethod() 
{
	return new FalconCore();
}


