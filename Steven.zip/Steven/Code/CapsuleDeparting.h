/**
	@file CapsuleDeparting.h
	@brief	
		Participant - Concrete State (State)
		Describes the methods of a Capusle that is in a 'departing' state.
	@author The 6 Musakteers
*/

#ifndef CAPSULEDEPARTING_H
#define CAPSULEDEPARTING_H

using namespace std;
#include <iostream>

class CapsuleState;
class RocketCapsule;
class CapsuleDeparting : public CapsuleState 
{
	public:

		/**
			@brief Constructor for CapsuleDeparting objects.
		*/
		CapsuleDeparting();

		/**
			@brief Returns the state that the capsule is currently in (Departing).
			@return string
		*/
		string getState();

		/**
			@brief Handles a change in state - sets the state of the current capsule to 'arriving'.
			@param c RocketCapsule*
			@return void
		*/
		void handleChange(RocketCapsule* c);
};

#endif
