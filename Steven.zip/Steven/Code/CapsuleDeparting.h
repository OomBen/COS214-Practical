#ifndef CAPSULEDEPARTING_H
#define CAPSULEDEPARTING_H

using namespace std;
#include <iostream>

class CapsuleState;
class RocketCapsule;
class CapsuleDeparting : public CapsuleState 
{
	public:
		CapsuleDeparting();
		string getState();
		void handleChange(RocketCapsule* c);
};

#endif
