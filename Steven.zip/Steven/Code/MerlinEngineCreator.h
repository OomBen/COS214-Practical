#ifndef MERLINENGINECREATOR_H
#define MERLINENGINECREATOR_H

#include "ComponentCreator.h"
#include "Component.h"
#include "MerlinEngine.h"

class MerlinEngineCreator : public ComponentCreator 
{
	public:
		Component* factoryMethod();
		Component* clone(Component* C);
};

#endif
