#include "CapsuleStateHierarchy.h"

CapsuleOffline::CapsuleOffline(){}

string CapsuleOffline::getState(){
    return "Offline";
}

//?
void CapsuleOffline::handleChange(RocketCapsule* s){
    //we have to specify the state it is setting
    //for now, putting departing
    s->setState(new CapsuleDeparting());
}

CapsuleDocked::CapsuleDocked(){}

string CapsuleDocked::getState()
{
    return "Docked";
}

void CapsuleDocked::handleChange(RocketCapsule* c)
{
    c->setState(new CapsuleOffline());
}

CapsuleDeparting::CapsuleDeparting(){}

string CapsuleDeparting::getState()
{
    return "Departing";
}

void CapsuleDeparting::handleChange(RocketCapsule* c)
{
    c->setState(new CapsuleArriving());
}

CapsuleArriving::CapsuleArriving(){}

string CapsuleArriving::getState(){
    return "Arriving";
}

void CapsuleArriving::handleChange(RocketCapsule* c){
    c->setState(new CapsuleDocked());
}
