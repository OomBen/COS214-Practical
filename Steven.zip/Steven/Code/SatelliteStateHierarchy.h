#ifndef SATELLITESTATE_HIERARCHY
#define SATELLITESTATE_HIERARCHY

#include <string>
#include <iostream>

#include "Satellite.h"

//class Satellite;

using namespace std;

class SatelliteState 
{
	public:
		virtual string getType() = 0;
		virtual void handleChange(Satellite* S) = 0;
};

class Broadcasting : public SatelliteState 
{
	public:
		/**
			@brief Constructor for the Broadcasting object.
		*/
		Broadcasting();

		/**
			@brief Returns the type of state the satellite is currently in (Broadcasting).
			@return string
		*/
		string getType();

		/**
			@brief Handles a change in state - sets the current state of the satellite to offline.
			@param s Satellite*
			@return void
		*/
		void handleChange(Satellite* s);
};

class Online : public SatelliteState 
{
	public:
		Online();
		string getType();
		void handleChange(Satellite* s);
};

class Offline: public SatelliteState 
{
	public:
		Offline();
		string getType();
		void handleChange(Satellite* s);
};

#endif //SATELLITESTATE_HIERARCHY
