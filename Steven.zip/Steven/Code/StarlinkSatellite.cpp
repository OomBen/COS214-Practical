#include "StarlinkSatellite.h"

StarlinkSatellite::StarlinkSatellite(int ID):Satellite(ID)
{
	//Nothing to do here: Construction logic implemented in parent
}

SatelliteState* StarlinkSatellite::getState() 
{
	return this->satelliteState;
}

void StarlinkSatellite::setState(SatelliteState* s) 
{
	this->satelliteState = s;
}