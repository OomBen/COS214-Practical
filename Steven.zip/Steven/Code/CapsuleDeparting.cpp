#include "CapsuleDeparting.h"
#include "CapsuleArriving.h"
#include "CapsuleState.h"
#include "RocketCapsule.h"

CapsuleDeparting::CapsuleDeparting(){}

string CapsuleDeparting::getState(){
    return "Departing";
}

void CapsuleDeparting::handleChange(RocketCapsule* c){
    c->setState(new CapsuleArriving());
}
