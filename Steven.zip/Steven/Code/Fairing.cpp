#include "Fairing.h"

Fairing::Fairing(Component* r): RocketCapsule(r)
{
	this->capsuleType = "Fairing";
}

void Fairing::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Fairing | Status: " << state->getState() << " | Satellites: " << getSatellites() << " | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void Fairing::test() 
{
	result = this->cost > 0 ? "Pass" : "Fail";
	cout << "Cost Test: " << result << endl;

	result = this->capsuleType != "" ? "Pass" : "Fail";
	cout << "Capsule Test: " << result << endl;

	result = this->rocketType != "" ? "Pass" : "Fail";
	cout << "Rocket Test: " << result << endl;
	//Ternary form equivalent of the statement
	// if(this->cost > 0)
	// {
	// 	string result = "Pass";
	// }
	// else
	// {
	// 	string result = "Fail";
	// }
}

vector<Satellite> Fairing::getSatellites() 
{
	return this->satellites;
}

//not right yet
void Fairing::setSatellites(vector<Satellite*> s) {
	this->satellites = s;
}
