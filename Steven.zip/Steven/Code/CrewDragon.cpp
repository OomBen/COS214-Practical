#include "CrewDragon.h"

CrewDragon::CrewDragon(Component* r): RocketCapsule(r)
{
	this->capsuleType = "Crew Dragon";
}

void CrewDragon::simulate() 
{
	//Might need to add more stuff to output here
	cout << capsuleType << " State: " << getState() << endl;
}

void CrewDragon::test() 
{
	// TODO - implement CrewDragon::test
	throw "Not yet implemented";
}

string[] CrewDragon::getPassengers() 
{
	return passengers;
}

void CrewDragon::setPassengers(string[] temp) {
	for (int i=0; i<sizeof(temp)/sizeof(temp[0]);i++) {
		passengers[i]=temp[i];
	}
	for (int i = sizeof(temp)/sizeof(temp[0]);i<7;i++){
		passengers[i]="";
	}
}
