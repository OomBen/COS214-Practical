/**
	@file ComponentCreator.h
	@brief 
	Participant - Creator (Factory Method)
	Defines the interface creating the Merlin, Vacuum Merlin and Core Engines 
	@author The 6 Muskateers
*/

#ifndef COMPONENTCREATOR_H
#define COMPONENTCREATOR_H

#include "Component.h"

class ComponentCreator 
{
	private:
		Component* component;

	public:
		/**
			@brief Pure virtual functon to be implemented in all the children classes.
			Factory method to create different types of engines.
			@return Component*
		*/
		virtual Component* factoryMethod() = 0;

		/**
			@brief Pure virtual functon to be implemented in all the children classes.
			Clone method used to create copies of the created engines.
			@param C Component*
			@return Component*
		*/
		virtual Component* clone(Component* C) = 0;
};

#endif
