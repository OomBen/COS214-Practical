#ifndef ROCKETCAPSULE_H
#define ROCKETCAPSULE_H

#include "Component.h"
#include "CapsuleState.h"
#include "CapsuleArriving.h"
#include "CapsuleDeparting.h"
#include "CapsuleDocked.h"
#include "CapsuleOffline.h"

class CapsuleState;

class RocketCapsule : public Component 
{
	protected:
		string capsuleType;
		CapsuleState* state;

	private:
		Component* rocket;
		double payloadWeight;
		
	public:
		RocketCapsule(Component* r);
		virtual void simulate() = 0;
		virtual void test() = 0;
		void addCapsule(Component* r);
		void requestStateChange();
//        CapsuleState* getState();
		void setState(CapsuleState* s);
		double getPayloadWeight();
		void setPayloadWeight(double);
        //void setState(CapsuleState* c);
		virtual void setPassengers(vector<string>){};
		virtual void setSatellites(vector<Satellite*>){};
};

#endif
