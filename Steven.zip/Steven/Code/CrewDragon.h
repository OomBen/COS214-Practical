#ifndef CREWDRAGON_H
#define CREWDRAGON_H

#include "RocketCapsule.h"

#include <vector>

class CrewDragon : public RocketCapsule 
{
	private:
		vector<string> passengers;

	public:
		CrewDragon(Component* r);
		void simulate();
		void test();
		vector<string> getPassengers();
		void setPassengers(vector<string>);
};

#endif
