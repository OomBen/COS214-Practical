#ifndef CREWDRAGON_H
#define CREWDRAGON_H

#include "RocketCapsule.h"

class CrewDragon : public RocketCapsule 
{
	private:
	//this may give an error
		string passengers[7];

	public:
		CrewDragon(Component* r);
		void simulate();
		void test();
		string[] getPassengers();
		void setPassangers(string[]);
};

#endif
