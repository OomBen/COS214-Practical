/**
	@file Component.h
	@brief 
	Participant - Component (Decorator), Component (Composite), Client (Chain of Responsibility), Product (Builder), Product (Factory Method), Client (Prototype), Implementor (Brdige)
	Defines the attributes and methods for the class used for communication between the satellites.
	@author The 6 Muskateers
*/

#ifndef COMPONENT_H
#define COMPONENT_H

#include <string>
#include <iostream>

using namespace std;

class Component 
{
	protected:
		double cost;
		string rocketType;
		string capsuleType;

	public:
		/**
			@brief Constructor for Component objects. Takes in the cost as a parameter and initializes the cost variable.
			@param c double 
		*/
		Component(double c);

		/**
			@brief Pure virtual function that needs to be implemented in all the children classes.
			Starts the simulation for Component objects. 
			@return void
		*/
		virtual void simulate() = 0;

		/**
			@brief Tests if the Component meets all the requirements for a successful launch. 
			The requirements depend on the type of Component.
			@return void
		*/
		virtual void test() = 0;

		/**
			@brief Adds a component to the rocket.
			@param c Component*
			@return void
		*/
		virtual void add(Component* c)

		/**
			@brief Virtual method that removes a component from the rocket based on its position.
			@param pos int
			@return void
		*/
		virtual void remove(int pos);

		/**
			@brief Virtual method that returns a component of the rocket based on its position.
			@param pos int 
			@return Component*
		*/
		virtual Component* getComponent(int pos);

		/**
			@brief Creates a clone of the current component.
			@return Component*
		*/
		Component* clone();

		/**
			@brief Returns the cost of the component.
			@return double
		*/
		double getCost();
};

float rocketCost;

#endif
