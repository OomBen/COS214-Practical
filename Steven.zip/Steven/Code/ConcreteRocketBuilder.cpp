#include "ConcreteRocketBuilder.h"

ConcreteRocketBuilder::ConcreteRocketBuilder(){
    merlinCreator = new MerlinEngineCreator();
    vacuumMerlinCreator = new VacuumMerlinEngineCreator();
    coreCreator = new CoreCreator();
    rocket = new ComponentComposite();
    capsule = NULL;
    simulationState = new SimulationState();
}

Component* ConcreteRocketBuilder::getSpacecraft() {
    return this->capsule;
}

void ConcreteRocketBuilder::buildFalcon9() {
    simulationState -> setRocketType("Falcon9");
	Component* core = coreCreator -> factoryMethod();

    Component* merlinEngines = new ComponentComposite();
    for(int i = 0; i < 27; i++){
        merlinEngines -> add(merlinCreator -> factoryMethod());
    }

    Component* vacuumMerlin = vacuumMerlinCreator -> factoryMethod();

    rocket -> add(core);
    rocket -> add(merlinEngines);
    rocket -> add(vacuumMerlin);
}

void ConcreteRocketBuilder::buildFalconHeavy() {
    simulationState -> setRocketType("FalconHeavy");
    Component* cores = new ComponentComposite();
    for(int i = 0; i < 3; i++){
        cores -> add(coreCreator -> factoryMethod());
    }

    Component* merlinEngines = new ComponentComposite();
    for(int i = 0; i < 27; i++){
        merlinEngines -> add(merlinCreator -> factoryMethod());
    }

    Component* vacuumMerlin = vacuumMerlinCreator -> factoryMethod();

    rocket -> add(cores);
    rocket -> add(merlinEngines);
    rocket -> add(vacuumMerlin);
}

void ConcreteRocketBuilder::constructCapsule(string type){
    simulationState -> setCapsuleType(type);
    //all need payload

    if(type == "Crew Dragon"){
        capsule = new CrewDragon(rocket);

        //get size of array for passengers
        input = "";
        int size = 0;
        bool flag;
        do {
            flag = true;
            do {
                flag = true;
                cout<<"How many passengers are there? The maximum amount of passengers is 7\n";
                getline (cin, input);
                for (int i = 0; i<input.length();i++) {
                    if (isdigit(input.at(i))) {
                        flag=false;
                        break;
                    }
                }
            } while (flag);
            size = stoi(input); //or use string stream
        }while (size<=0||size>7);
        
        //fill passenger array
        string passengers [size];
        input = "";
        int i = 0;
        do {
            cout<<"Input the name of passenger #"<<i+1<<"\n";
            getline (cin, input);
            passengers[i]=input;
            i++;
        }while (i<size);

        capsule->setPassengers(passengers);
        simulationState->setPassengers(passengers);
    }

    else if(type == "Cargo Dragon"){
        capsule = new CargoDragon(rocket);

    }
    else if(type == "Fairing"){

        capsule = new Fairing(rocket);

        //get size of array for satellites
        input = "";
        do {
            flag = true;
            cout<<"How many satellites are there?\n";
            getline (cin, input);
            for (int i = 0; i<input.length();i++) {
                if (isdigit(input.at(i))) {
                    flag=false;
                    break;
                }
            }
        } while (flag);
        int size = stoi(input); //or use string stream

        //fill satellite array
        Satellite* satellites [size];
        input = "";
        int i = 0;
        do {
            SatelliteCreator* temp = new StarlinkCreator();
            Satellite* sat = temp->factoryMethod();
            satellites[i] = sat;
            i++;
        }while (i<size);

        capsule->setSatellites(satellites);
        simulationState->setSatellites(satellites);

    }
    //get the payload for the capsule 
        string input = "";
        bool flag;
        do {
            flag = true;
            cout<<"What is the payload weight of the capsule?\n";
            cin>>input;
            for (int i = 0; i<input.length();i++) {
                if (isdigit(input.at(i))) {
                    flag=false;
                    break;
                }
            }
        } while (flag);
        double payload = std::stod(input);
        capsule->setPayloadWeight(payload);
        simulationState->setPayloadWeight(payload);
}

Simulation* ConcreteRocketBuilder::createSimulation(){
    simulation = new Simulation(capsule, rocket, simulationState);
}