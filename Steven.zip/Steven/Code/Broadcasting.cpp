#include "Broadcasting.h"
#include "Offline.h"

Broadcasting::Broadcasting(){}

string Broadcasting::getType() 
{
	return "Broadcasting";
}

void BroadCasting::handleChange(Satellite* s)
{
	s->setState(new Offline());
}
// void RedState::handleChange(Context* c) {
//     c->setState(new GreenState());
// }