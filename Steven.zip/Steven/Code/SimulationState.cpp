#include "SimulationState.h"

string SimulationState::getCapsuleType() {
	return this->capsuleType;
}

string SimulationState::getRocketType() {
	return this->rocketType;
}

double SimulationState::getPayloadWeight() {
	return this->payloadWeight;
}

Satellite* SimulationState::getSatellites() {
	return this->satellites;
}

string* SimulationState::getPassengers() {
	return this->passengers;
}

void SimulationState::setCapsuleType(string c){
	capsuleType = 
}

void SimulationState::setRocketType(string s){
	rocketType = r;
}

void SimulationState::setPayloadWeight(double p){
	payloadWeight = p;
}

void SimulationState::setSatellites(Satellite*[] s){
	satellites = s;
}

void SimulationState::setPassengers(string* s){
	passengers = s;
}

SimulationState::SimulationState(){
	// TODO - implement SimulationState::SimulationState
	throw "Not yet implemented";
}

