#ifndef DIRECTOR_H
#define DIRECTOR_H

#include <string>
#include <iostream>

#include "Builder.h"

using namespace std;

class Director 
{
	private:
		Builder* builder;

	public:
		Director (Builder * b);
		Component* construct();
		void constructCapsule();
		Simulation* createSimulation();
};

#endif
