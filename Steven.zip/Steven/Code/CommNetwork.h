#ifndef COMMNETWORK_H
#define COMMNETWORK_H

#include <string>
#include <vector>
#include "Mediator.h"
#include "Satellite.h"

class CommNetwork : public Mediator {
	public:
		vector<Satellite*> colleagueList;
		
	public:
		void notify(Satellite* colleague);
};

#endif