#ifndef MEDIATOR_H
#define MEDIATOR_H

#include <string>
#include <iostream>

#include "Satellite.h"
class Satellite;
using namespace std;

class Mediator {


public:
	virtual void notify(Satellite* colleague) = 0;
};

#endif
