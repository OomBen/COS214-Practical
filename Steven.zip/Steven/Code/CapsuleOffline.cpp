#include "CapsuleOffline.h"

CapsuleOffline::CapsuleOffline(){}

string CapsuleOffline::getState(){
    return "Offline";
}

void CapsuleOffline::handleChange(RocketCapsule* s){
    s->setState();
}


