#include "CapsuleOffline.h"

CapsuleOffline::CapsuleOffline(){}

string CapsuleOffline::getState(){
    return "Offline";
}

//?
void CapsuleOffline::handleChange(RocketCapsule* s){
    //we have to specify the state it is setting
    //for now, putting departing
    s->setState(new CapsuleDeparting());
}


