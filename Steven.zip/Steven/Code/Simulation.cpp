#include "Simulation.h"

Simulation::Simulation(Component* c,Component* r, SimulationState* s) {
	simulationSate = s;
	rocket = r;
	capsule = c;
}

void Simulation::staticFireTest() {
	// TODO - implement Simulation::staticFireTest
	throw "Not yet implemented";
}

void Simulation::launch() {
	// TODO - implement Simulation::launch
	throw "Not yet implemented";
}

Memento* Simulation::createMemento () {

}

Memento* Simulation::restoreMemento(Memento*) {

}
