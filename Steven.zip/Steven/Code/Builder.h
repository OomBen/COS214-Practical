#ifndef BUILDER_H
#define BUILDER_H

#include <iostream>
#include <string>
#include "Component.h"

using namespace std;
class Builder 
{
	public:
		virtual void buildFalcon9() = 0;
		virtual void buildFalconHeavy() = 0;
		virtual void constructCapsule(string type) = 0;
		virtual Component*  getSpacecraft() = 0;
		Simulation* createSimulation() = 0;
};

#endif
