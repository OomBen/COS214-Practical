#ifndef CORECREATOR_H
#define CORECREATOR_H

#include "ComponentCreator.h"
#include "Component.h"
#include "FalconCore.h"

//Factory Method Concrete Creator
class CoreCreator : public ComponentCreator 
{
	public:
		Component* factoryMethod();
		Component* clone(Component* C);
};

#endif
