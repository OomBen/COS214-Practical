#ifndef FAIRING_H
#define FAIRING_H

#include "RocketCapsule.h"
#include "Satellite.h"

class Fairing : public RocketCapsule 
{
	private:
		Satellite* [] satellites;

	public:
		Fairing(Component*);
		void simulate();
		void test();
		Satellite* getSatellites();
		void setSatellites(Satellite* [] s);
};

#endif
