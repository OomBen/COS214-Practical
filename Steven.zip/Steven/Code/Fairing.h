#ifndef FAIRING_H
#define FAIRING_H

#include "RocketCapsule.h"
#include "Satellite.h"

#include <vector>

class Fairing : public RocketCapsule 
{
	private:
		vector<Satellite*> satellites;

	public:
		Fairing(Component*);
		void simulate();
		void test();
		vector<Satellite*> getSatellites();
		void setSatellites(vector<Satellite*> s);
};

#endif
