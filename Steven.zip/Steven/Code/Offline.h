#ifndef OFFLINE_H
#define OFFLINE_H

#include "SatelliteState.h"

using namespace std;
class Satellite;
class Offline: public SatelliteState 
{
	public:
		Offline();
		string getType();
		void handleChange(Satellite* s);
};

#endif
