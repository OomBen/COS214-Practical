#ifndef SATELLITESTATE_H
#define SATELLITESTATE_H

#include <string>
#include <iostream>

using namespace std;

class Satellite;
class SatelliteState 
{
	public:
		virtual string getType() = 0;
		virtual void handleChange(Satellite* S) = 0;
};

#endif