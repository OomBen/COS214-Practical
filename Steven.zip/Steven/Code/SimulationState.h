#ifndef SIMULATIONSTATE_H
#define SIMULATIONSTATE_H

#include "Component.h"
#include "Satellite.h"

#include <string>
#include <iostream>
#include <vector>

using namespace std;

class SimulationState {

private:
	Component* rocket;
	string capsuleType;
	string rocketType;
	double payloadWeight;
	vector<Satellite*> satellites;
	vector<string> passengers;
	vector<string> methodCalls;

public:
	SimulationState();	
	string getCapsuleType();
	string getRocketType();
	double getPayloadWeight();
	vector<Satellite*> getSatellites();
	vector<string> getPassengers();
	vector<string> getMethodCalls();

	void setCapsuleType(string s);
	void setRocketType(string s);
	void setPayloadWeight(double d);
	void setSatellites(vector<Satellite*> s);
	void setPassengers(vector<string>);

	void addCall(string c);
};

#endif
