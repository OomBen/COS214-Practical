#ifndef SIMULATIONSTATE_H
#define SIMULATIONSTATE_H

#include "Component.h"
#include "Satellite.h"

#include <string>
#include <iostream>

using namespace std;

class SimulationState {

private:
	Component* rocket;
	string capsuleType;
	string rocketType;
	double payloadWeight;
	Satellite*[] satellites;
	string* passengers;

public:
	string getCapsuleType();

	string getRocketType();

	double getPayloadWeight();

	Satellite* getSatellites();

	string* getPassengers();

	void setCapsuleType(string s);

	void setRocketType(string s);

	void setPayloadWeight(double d);

	void setSatellites(Satellite*[] s);

	void setPassengers(string* s);

	SimulationState();
};

#endif
