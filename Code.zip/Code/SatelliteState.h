#ifndef SATELLITESTATE_H
#define SATELLITESTATE_H

#include <string>
#include <iostream>

using namespace std;

class SatelliteState {


public:
	virtual void changeInternalState() = 0;

	virtual string getType() = 0;
};

#endif
