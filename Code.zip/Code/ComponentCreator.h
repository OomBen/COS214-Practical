#ifndef COMPONENTCREATOR_H
#define COMPONENTCREATOR_H

#include "Component.h"

class ComponentCreator 
{
	private:
		Component* component;

	public:
		virtual Component* factoryMethod() = 0;
		virtual Component* clone(Component* C) = 0;
};

#endif
