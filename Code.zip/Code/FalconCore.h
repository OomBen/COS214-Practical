#ifndef FALCONCORE_H
#define FALCONCORE_H

#include "Componet"

class FalconCore : public Component 
{
	public:
		void simulate();
		void test();
};

#endif
