#ifndef FALCONCORE_H
#define FALCONCORE_H

#include "Component.h"

class FalconCore : public Component 
{
	public:
		void simulate();
		void test();
};

#endif
