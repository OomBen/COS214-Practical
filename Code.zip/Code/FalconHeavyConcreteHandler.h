#ifndef FALCONHEAVYCONCRETEHANDLER_H
#define FALCONHEAVYCONCRETEHANDLER_H

#include "ComponentComposite.h"

class FalconHeavyConcreteHandler : public ComponentComposite 
{
	public:
		void handleStagingRequest();
};

#endif
