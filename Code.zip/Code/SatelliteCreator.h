#ifndef SATELLITECREATOR_H
#define SATELLITECREATOR_H

#include <iostream>>
#include <string>

#include "Satellite.h"

using namespace std;

class SatelliteCreator 
{
	private:
		Satellite* satellite;

	public:
		Satellite* factoryMethod();
};

#endif
