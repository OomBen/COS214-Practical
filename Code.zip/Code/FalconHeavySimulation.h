#ifndef FALCONHEAVYSIMULATION_H
#define FALCONHEAVYSIMULATION_H

#include "Simulation.h"

class FalconHeavySimulation : public Simulation {


public:
	void tweakSimulation();
};

#endif
