#include "MerlinEngine .h"

void MerlinEngine_::simulate() {
	// TODO - implement MerlinEngine ::simulate
	throw "Not yet implemented";
}

void MerlinEngine_::test() {
	// TODO - implement MerlinEngine ::test
	throw "Not yet implemented";
}
