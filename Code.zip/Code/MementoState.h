#ifndef MEMENTOSTATE_H
#define MEMENTOSTATE_H

#include <iostream>
#include <string>

#include "Component.h"
#include "Satellite.h"

class MementoState {

private:
	Component* rocket;
	double cost;
	string capsuleType;
	string rocketType;
	double payloadWeight;
	Satellite* satellites;
	string* passengers;

public:
	string getCapsuleType();

	string getRocketType();

	double getPayloadWeight();

	Satellite* getSatellites();

	string* getPassengers();

	MementoState(string rocketType, double cost, string capsuleType, double payloadWeight, Satellites* satellites[], string passengers[]);

	MementoState(string rocketType, double cost);
};

#endif
