#include "CommNetwork.h"

void CommNetwork::notify(Satellite* colleague) {
	vector<Satellite*>::iterator it = colleagueList.begin();
	while ((it != colleagueList.end())) {
		(*it)->receiveStateInfo("Satellite " + colleague->getID() + ": changed state to " +  colleague->getState()->getType());
		++it;
	}
}
