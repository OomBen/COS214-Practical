#include "CommNetwork.h"

void CommNetwork::notify(Satellite* colleague) {
	// TODO - implement CommNetwork::notify
	throw "Not yet implemented";
}
