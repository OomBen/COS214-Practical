#include "ConcreteRocketBuilder.h"

void ConcreteRocketBuilder::getSpacecraft() {
	// TODO - implement ConcreteRocketBuilder::getSpacecraft
	throw "Not yet implemented";
}

void ConcreteRocketBuilder::buildRocket() {
	// TODO - implement ConcreteRocketBuilder::buildRocket
	throw "Not yet implemented";
}
