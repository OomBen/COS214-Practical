#ifndef SIMULATIONSTATE_H
#define SIMULATIONSTATE_H

#include "Comonent.h"
#include "Satellite.h"

#include <string>
#include <iostream>

using namespace std;

class SimulationState {

private:
	Component* rocket;
	double cost;
	string capsuleType;
	string rocketType;
	double payloadWeight;
	Satellite* satellites;
	string* passengers;

public:
	string getCapsuleType();

	string getRocketType();

	double getPayloadWeight();

	Satellite* getSatellites();

	string* getPassengers();

	SimulationState(string rocketType, double cost, string capsuleType, double payloadWeight, Satellite* satellites, string passengers[]);

	SimulationState(string rocketType, double cost);
};

#endif
