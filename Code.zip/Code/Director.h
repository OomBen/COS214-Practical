#ifndef DIRECTOR_H
#define DIRECTOR_H

#include <string>
#include <iostream>

#include "Builder.h"

//include the rocketcapsules so we can call the constructors
#include "CrewDragon.h"
#include "CargoDragon.h"
#include "Fairing.h"


using namespace std;

class Director 
{
	private:
		Builder* builder;

	public:
		Director (Builder * b);
		Component* construct();
};

#endif
