#ifndef DIRECTOR_H
#define DIRECTOR_H

#include <string>
#include <iostream>

#include "Builder.h"

using namespace std;

class Director 
{
	private:
		Builder* builder;

	public:
		void construct();
};

#endif
