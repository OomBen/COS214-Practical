#ifndef FALCON9SIMULATION_H
#define FALCON9SIMULATION_H

#include "Simulation.h"

class Falcon9Simulation : public Simulation {


public:
	void tweakSimulation();
};

#endif
