#include "CapsuleDocked.h"

void CapsuleDocked::changeInternalState() {
	// TODO - implement CapsuleDocked::changeInternalState
	throw "Not yet implemented";
}
