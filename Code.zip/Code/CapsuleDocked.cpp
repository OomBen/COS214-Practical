#include "CapsuleDocked.h"

void CapsuleDocked::changeInternalState(RocketCapsule* R) 
{
	R->state = new CapsuleDe;
}
