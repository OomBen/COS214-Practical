#include "VacuumMerlinEngineCreator.h"

Component* VacuumMerlinEngineCreator::factoryMethod() {
	//return new VacuumMerlinEngine();
}

Component* VacuumMerlinEngineCreator::clone(Component* C) {
	// TODO - implement VacuumMerlinEngineCreator::clone
	throw "Not yet implemented";
}
