#include "VacuumMerlinEngineCreator.h"

Component* VacuumMerlinEngineCreator::factoryMethod() 
{
	return new VacuumMerlinEngine();
}

Component* VacuumMerlinEngineCreator::clone(Component* C) 
{
	Component* newClone = new VacuumMerlinEngine();
	newClone->cost = C->getCost();
	newClone->rocketType = C->rocketType;
	newClone->capsuleType = C->capsuleType;
	return newClone;
}
