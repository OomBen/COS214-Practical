#include "VacuumMerlinEngineCreator.h"

Component* VacuumMerlinEngineCreator::factoryMethod() {
	// TODO - implement VacuumMerlinEngineCreator::factoryMethod
	throw "Not yet implemented";
}

Component* VacuumMerlinEngineCreator::clone(Component* C) {
	// TODO - implement VacuumMerlinEngineCreator::clone
	throw "Not yet implemented";
}
