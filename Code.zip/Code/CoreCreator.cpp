#include "CoreCreator.h"

Component* CoreCreator::factoryMethod() {
	//return new FalconCore();
}

Component* CoreCreator::clone(Component* C) {
	// TODO - implement CoreCreator::clone
	throw "Not yet implemented";
}
