#include "CoreCreator.h"

Component* CoreCreator::factoryMethod() 
{
	return new FalconCore();
}

Component* CoreCreator::clone(Component* C) 
{
	Component* newClone = new FalconCore();
	newClone->cost = C->getCost();
	newClone->rocketType = C->rocketType;
	newClone->capsuleType = C->capsuleType;
	return newClone;
}

