#include "CoreCreator.h"

Component* CoreCreator::factoryMethod() {
	// TODO - implement CoreCreator::factoryMethod
	throw "Not yet implemented";
}

Component* CoreCreator::clone(Component* C) {
	// TODO - implement CoreCreator::clone
	throw "Not yet implemented";
}
