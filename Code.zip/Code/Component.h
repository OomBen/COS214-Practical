#ifndef COMPONENT_H
#define COMPONENT_H

#include <string>
#include <iostream>

using namespace std;

class Component {

protected:
	double cost;

public:
	Component(double c);

	virtual void simulate() = 0;

	virtual void test() = 0;

	void add(Component* c);

	void remove(int pos);

	Component* getComponent(int pos);

	Component* clone();

	double getCost();
};

#endif
