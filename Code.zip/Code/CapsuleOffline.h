#ifndef CAPSULEOFFLINE_H
#define CAPSULEOFFLINE_H

#include "CapsuleState.h"
#include "RocketCapsule.h"

class CapsuleOffline : public CapsuleState 
{
	public:
		void changeInternalState(RocketCapsule* R);
		string getState();
};

#endif
