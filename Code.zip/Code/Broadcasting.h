#ifndef BROADCASTING_H
#define BROADCASTING_H

#include "SatelliteState.h"
#include "Satellite.h"

class Broadcasting : public SatelliteState 
{
	public:
		Broadcasting();
		void changeInternalState(Satellite* S);
		string getType();
};

#endif
