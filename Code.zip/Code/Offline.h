#ifndef OFFLINE_H
#define OFFLINE_H

#include "SatelliteState.h"

class Offline : public SatelliteState 
{
	public:
		void changeInternalState();

		string getType();
};

#endif
