#ifndef OFFLINE_H
#define OFFLINE_H

#include "SatelliteState.h"
#include "Satellite.h"

class Offline : public SatelliteState 
{
	public:
		Offline();
		void changeInternalState(Satellite* S);
		string getType();
};

#endif
