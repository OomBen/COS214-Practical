#include "SatelliteCreator.h"

Satellite* SatelliteCreator::factoryMethod() {
	return new StarlinkSatellite();
}
