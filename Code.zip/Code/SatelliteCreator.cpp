#include "SatelliteCreator.h"

Satellite* SatelliteCreator::factoryMethod() {
	// TODO - implement SatelliteCreator::factoryMethod
	throw "Not yet implemented";
}
