#include "VacuumMerlinEngine.h"

void VacuumMerlinEngine::simulate() {
	// TODO - implement VacuumMerlinEngine ::simulate
	throw "Not yet implemented";
}

void VacuumMerlinEngine::test() {
	// TODO - implement VacuumMerlinEngine ::test
	throw "Not yet implemented";
}
