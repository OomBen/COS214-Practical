#include "VacuumMerlinEngine.h"

VacuumMerlinEngine::VacuumMerlinEngine()
{
	//https://www.quora.com/How-much-does-it-cost-to-produce-a-single-Merlin-engine-in-SpaceX-rockets?share=1
	this->cost = 400 000;
	
	//We don't know what the rocketType is at this point so we leave those attributes uninstantiated
	//We also don't know what the capsuleType is at this point so we leave those attributes uninstantiated
}

void VacuumMerlinEngine::simulate() {
	// TODO - implement VacuumMerlinEngine ::simulate
	throw "Not yet implemented";
}

void VacuumMerlinEngine::test() {
	// TODO - implement VacuumMerlinEngine ::test
	throw "Not yet implemented";
}
