#include "Caretaker.h"

Caretaker::Caretaker() {
	// TODO - implement Caretaker::Caretaker
	throw "Not yet implemented";
}

void Caretaker::storeMemento(Memento* m) {
	// TODO - implement Caretaker::storeMemento
	throw "Not yet implemented";
}

Memento* Caretaker::retrieveMemento() {
	// TODO - implement Caretaker::retrieveMemento
	throw "Not yet implemented";
}
