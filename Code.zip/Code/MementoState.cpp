#include "MementoState.h"

string MementoState::getCapsuleType() {
	return this->capsuleType;
}

string MementoState::getRocketType() {
	return this->rocketType;
}

double MementoState::getPayloadWeight() {
	return this->payloadWeight;
}

Satellite* MementoState::getSatellites() {
	return this->satellites;
}

string* MementoState::getPassengers() {
	return this->passengers;
}

MementoState::MementoState(string rocketType, double cost, string capsuleType, double payloadWeight, Satellite* satellites[], string passengers[]) {
	// TODO - implement MementoState::MementoState
	throw "Not yet implemented";
}

MementoState::MementoState(string rocketType, double cost) {
	// TODO - implement MementoState::MementoState
	throw "Not yet implemented";
}
