#include "MerlinEngine.h"

void MerlinEngine::simulate() {
	// TODO - implement MerlinEngine ::simulate
	throw "Not yet implemented";
}

void MerlinEngine::test() {
	// TODO - implement MerlinEngine ::test
	throw "Not yet implemented";
}
