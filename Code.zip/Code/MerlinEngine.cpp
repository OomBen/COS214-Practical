#include "MerlinEngine.h"

MerlineEngine::MerlinEngine()
{
	this->cost = 300 000;

	//We don't know what the rocketType is at this point so we leave those attributes uninstantiated
	//We also don't know what the capsuleType is at this point so we leave those attributes uninstantiated
}

void MerlinEngine::simulate() 
{
	// TODO - implement MerlinEngine ::simulate
	throw "Not yet implemented";
}

void MerlinEngine::test() {
	// TODO - implement MerlinEngine ::test
	throw "Not yet implemented";
}
