#include "StarlinkSatellite.h"

SatelliteState* StarlinkSatellite::getState() {
	// TODO - implement StarlinkSatellite::getState
	throw "Not yet implemented";
}

void StarlinkSatellite::setState(SatelliteState* s) {
	// TODO - implement StarlinkSatellite::setState
	throw "Not yet implemented";
}
