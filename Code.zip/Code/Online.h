#ifndef ONLINE_H
#define ONLINE_H

#include "SatelliteState.h"

class Online : public SatelliteState 
{
	public:
		void changeInternalState();
		string getType();
};

#endif
