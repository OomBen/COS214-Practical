#ifndef ONLINE_H
#define ONLINE_H

#include "SatelliteState.h"
#include "Satellite.h"

class Online : public SatelliteState 
{
	public:
		Online();
		void changeInternalState(Satellite* S);
		string getType();
};

#endif
