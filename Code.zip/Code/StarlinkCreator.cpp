#include "StarlinkCreator.h"

StarlinkSatellite* StarlinkCreator::factoryMethod() {
	// TODO - implement StarlinkCreator::factoryMethod
	throw "Not yet implemented";
}
