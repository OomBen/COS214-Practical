#include "VacuumMerlinEngine .h"

void VacuumMerlinEngine_::simulate() {
	// TODO - implement VacuumMerlinEngine ::simulate
	throw "Not yet implemented";
}

void VacuumMerlinEngine_::test() {
	// TODO - implement VacuumMerlinEngine ::test
	throw "Not yet implemented";
}
