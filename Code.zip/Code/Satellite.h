#ifndef SATELLITE_H
#define SATELLITE_H

#include <iostream>

#include "SatelliteState.h"
#include "Mediator.h"
#include "Observer.h"

using namespace std;

class Satellite {

protected:
	SatelliteState* satelliteState;
private:
	Mediator* mediator;
	Observer* observerList;

public:
	void setState(State* s);

	void changed();

	Mediator* getMediator();

	void setMediator(Mediator* m);

	void requestStateChange();

	void attach(Observer o);

	void detatch(Observer o);

	void notify();
};

#endif
