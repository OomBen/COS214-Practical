#ifndef SATELLITE_H
#define SATELLITE_H

#include <iostream>

#include "SatelliteState.h"
#include "Mediator.h"
#include "Observer.h"

using namespace std;
class Mediator;
class Satellite {

protected:
	SatelliteState* satelliteState;
private:
	Mediator* mediator;
	Observer* observerList;

public:
	void changed();

	Mediator* getMediator();

	void setMediator(Mediator* m);

	void requestStateChange();

	void attach(Observer* o);

	void detach(Observer* o);

	void notify();
};

#endif
