#ifndef CAPSULEARRIVING_H
#define CAPSULEARRIVING_H

#include "CapsuleState.h"
#include "RocketCapsule.h"

class CapsuleArriving : public CapsuleState 
{
	public:
		void changeInternalState(RocketCapsule* R);
		string getState();
};

#endif
