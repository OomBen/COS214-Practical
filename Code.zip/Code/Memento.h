#ifndef MEMENTO_H
#define MEMENTO_H

#include <iostream>
#include <string>

#include "MementoState.h"

using namespace std;

class Memento 
{
	private:
		MementoState* state;

	public:
		MementoState* getState();
		void setState(MementoState* c);
		~Memento();
};

#endif
