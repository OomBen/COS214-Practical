#include "StarlinkSatelite.h"

SatelliteState* StarlinkSatelite::getState() {
	// TODO - implement StarlinkSatelite::getState
	throw "Not yet implemented";
}

void StarlinkSatelite::setState(SatelliteState* s) {
	// TODO - implement StarlinkSatelite::setState
	throw "Not yet implemented";
}
