#ifndef CAPSULEDOCKED_H
#define CAPSULEDOCKED_H
 
#include "CapsuleState.h"
#include "RocketCapsule.h"

class CapsuleDocked : public CapsuleState 
{
	public:
		void changeInternalState(RocketCapsule* R);
		string getState();
};

#endif
