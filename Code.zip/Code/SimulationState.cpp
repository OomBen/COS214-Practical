#include "SimulationState.h"

string SimulationState::getCapsuleType() {
	return this->capsuleType;
}

string SimulationState::getRocketType() {
	return this->rocketType;
}

double SimulationState::getPayloadWeight() {
	return this->payloadWeight;
}

Satellite* SimulationState::getSatellites() {
	return this->satellites;
}

string* SimulationState::getPassengers() {
	return this->passengers;
}

SimulationState::SimulationState(string rocketType, double cost, string capsuleType, double payloadWeight, Satellite* satellites, string passengers[]) {
	// TODO - implement SimulationState::SimulationState
	throw "Not yet implemented";
}

SimulationState::SimulationState(string rocketType, double cost) {
	// TODO - implement SimulationState::SimulationState
	throw "Not yet implemented";
}
