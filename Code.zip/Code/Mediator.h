#ifndef MEDIATOR_H
#define MEDIATOR_H

#include <string>
#include <iostream>

using namespace std;

class Mediator {


public:
	virtual void notify(Satellite* colleague) = 0;
};

#endif
