#ifndef MERLINENGINE_H
#define MERLINENGINE_H

#include "Component.h"

class MerlinEngine : public Component
{
	public:
		void simulate();
		void test();
};

#endif
