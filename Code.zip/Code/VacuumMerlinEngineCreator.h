#ifndef VACUUMMERLINENGINECREATOR_H
#define VACUUMMERLINENGINECREATOR_H

#include "ComponentCreator.h"
#include "Component.h"

class VacuumMerlinEngineCreator : public ComponentCreator 
{
	public:
		Component* factoryMethod();
		Component* clone(Component* C);
};

#endif