#include "CapsuleDeparting.h"
#include "CapsuleOffline.h"

void CapsuleDeparting::changeInternalState(RocketCapsule* R) 
{
	R->state = new CapsuleOffline();
}
