#include "CapsuleDeparting.h"

void CapsuleDeparting::changeInternalState() {
	// TODO - implement CapsuleDeparting::changeInternalState
	throw "Not yet implemented";
}
