#ifndef FAIRING_H
#define FAIRING_H

#include "RocketCapsule.h"
#include "Satellite.h"

class Fairing : public RocketCapsule 
{
	private:
		double payloadWeight;
		Satellite* satellites;

	public:
		Fairing();
		void simulate();
		void test();
		double getPayloadWeight();
		Satellite* getSatellites();
};

#endif
