#include "MerlinEngineCreator.h"

Component* MerlinEngineCreator::factoryMethod() {
	//return new MerlinEngine();
}

Component* MerlinEngineCreator::clone(Component* C) {
	// TODO - implement MerlinEngineCreator::clone
	throw "Not yet implemented";
}
