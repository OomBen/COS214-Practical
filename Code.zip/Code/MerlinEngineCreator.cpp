#include "MerlinEngineCreator.h"

Component* MerlinEngineCreator::factoryMethod() {
	// TODO - implement MerlinEngineCreator::factoryMethod
	throw "Not yet implemented";
}

Component* MerlinEngineCreator::clone(Component* C) {
	// TODO - implement MerlinEngineCreator::clone
	throw "Not yet implemented";
}
