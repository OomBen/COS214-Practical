#include "MerlinEngineCreator.h"

Component* MerlinEngineCreator::factoryMethod() 
{
	return new MerlinEngine();
}

Component* MerlinEngineCreator::clone(Component* C) 
{
	Component* newClone = new MerlinEngine();
	newClone->cost = C->getCost();
	newClone->rocketType = C->rocketType;
	newClone->capsuleType = C->capsuleType;
	return newClone;
}
