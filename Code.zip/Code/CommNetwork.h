#ifndef COMMNETWORK_H
#define COMMNETWORK_H

#include "Mediator.h"
#include "Satellite.h"

class CommNetwork : public Mediator {
	public:
		Satellite* colleagueList;
		
	public:
		void notify(Satellite* colleague);
};

#endif