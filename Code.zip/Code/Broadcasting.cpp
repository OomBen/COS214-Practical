#include "Broadcasting.h"

void Broadcasting::changeInternalState(Satellite* S) 
{
	S->satelliteState = new Offline();
}

string Broadcasting::getType() 
{
	return "Broadcasting";
}

// void RedState::handleChange(Context* c) {
//     c->setState(new GreenState());
// }