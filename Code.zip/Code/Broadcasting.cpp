#include "Broadcasting.h"

void Broadcasting::changeInternalState() {
	// TODO - implement Broadcasting::changeInternalState
	throw "Not yet implemented";
}

string Broadcasting::getType() {
	// TODO - implement Broadcasting::getType
	throw "Not yet implemented";
}
