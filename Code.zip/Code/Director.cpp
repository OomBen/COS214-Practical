#include "Director.h"

void Director::construct() {
	// TODO - implement Director::construct
	throw "Not yet implemented";
}
