#ifndef MERLINENGINE _H
#define MERLINENGINE _H

#include "Component.h"

class MerlinEngine_ : public Component 
{
	public:
		void simulate();
		void test();
};

#endif
