#include "FalconCore.h"

FalconCore::FalconCore()
{
	//https://space.stackexchange.com/questions/8330/what-is-the-cost-breakdown-for-a-falcon-9-launch
	this->cost = 30 000 000;
	
	//We don't know what the rocketType is at this point so we leave those attributes uninstantiated
	//We also don't know what the capsuleType is at this point so we leave those attributes uninstantiated
}

void FalconCore::simulate() 
{
	// TODO - implement FalconCore::simulate
	throw "Not yet implemented";
}

void FalconCore::test() {
	// TODO - implement FalconCore::test
	throw "Not yet implemented";
}
