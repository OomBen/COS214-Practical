#include "FalconCore.h"

void FalconCore::simulate() {
	// TODO - implement FalconCore::simulate
	throw "Not yet implemented";
}

void FalconCore::test() {
	// TODO - implement FalconCore::test
	throw "Not yet implemented";
}
