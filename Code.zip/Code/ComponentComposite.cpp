#include "ComponentComposite.h"

ComponentComposite::ComponentComposite(): Component(0){
	
}

void ComponentComposite::simulate() {
	for (auto c: components){
		c -> simulate();
	}
}

void ComponentComposite::test() {
	for (auto c: components){
		c -> test();
	}
}

void ComponentComposite::add(Component* c) {
	cost += c -> getCost();
	components.push_back(c);
}

void ComponentComposite::remove(int pos) {
	components.erase(pos);
}

Component* ComponentComposite::getComponent(int pos) {
	return components[pos];
}
