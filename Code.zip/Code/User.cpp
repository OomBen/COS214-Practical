#include "User.h"

void User::update() {
	// TODO - implement User::update
	throw "Not yet implemented";
}
