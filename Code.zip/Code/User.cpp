#include "User.h"

User::User(StarlinkSatellite* s)
{
	subject = s;
}

void User::update() {
	// TODO - implement User::update
	throw "Not yet implemented";
}
