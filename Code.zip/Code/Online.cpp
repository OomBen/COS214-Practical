#include "Online.h"

Online::Online(){}

void Online::changeInternalState() 
{
	S->satelliteState = new Broadcasting();
}

string Online::getType() {
	return "Online";
}
