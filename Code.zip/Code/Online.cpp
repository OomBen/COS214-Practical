#include "Online.h"

void Online::changeInternalState() {
	// TODO - implement Online::changeInternalState
	throw "Not yet implemented";
}

string Online::getType() {
	// TODO - implement Online::getType
	throw "Not yet implemented";
}
