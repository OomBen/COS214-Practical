#include "Fairing.h"

Fairing::Fairing()
{
	this->capsuleType = "Fairing";
}

void Fairing::simulate() 
{
	//Might need to add more stuff to output here
	cout << capsuleType << " State: " << getState() << endl;
}

void Fairing::test() 
{
	// TODO - implement Fairing::test
	throw "Not yet implemented";
}

double Fairing::getPayloadWeight() 
{
	return this->payloadWeight;
}

Satellite* Fairing::getSatellites() 
{
	return this->satellites;
}
