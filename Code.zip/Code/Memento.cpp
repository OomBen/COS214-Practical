#include "Memento.h"

MementoState* Memento::getState() {
	return this->state;
}

void Memento::setState(MementoState* c) {
	this->state = c;
}
