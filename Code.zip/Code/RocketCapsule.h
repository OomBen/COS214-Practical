#ifndef ROCKETCAPSULE_H
#define ROCKETCAPSULE_H

#include "Component.h"
#include "CapsuleState.h"
#include "CapsuleArriving.h"
#include "CapsuleDeparting.h"
#include "CapsuleDocked.h"
#include "CapsuleOffline.h"

class RocketCapsule : public Component 
{
	protected:
		string capsuleType;

	private:
		Component* rocket;
		CapsuleState* state;
		double payloadweight;
		
	public:
		RocketCapsule(Component*);
		virtual void simulate() = 0;
		virtual void test() = 0;
		void addCapsule(Component* r);
		void changeState();
        CapsuleState* getState();
		double getPayloadWeight();
        //void setState(CapsuleState* c);
};

#endif
