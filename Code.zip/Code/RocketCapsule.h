#ifndef ROCKETCAPSULE_H
#define ROCKETCAPSULE_H

#include "Component.h"
#include "CapsuleState.h"

class RocketCapsule : public Component 
{
	protected:
		string capsuleType;

	private:
		Component* rocket;
		CapsuleState* state;
		
	public:
		RocketCapsule();
		virtual void simulate() = 0;
		virtual void test() = 0;
		void addCapsule(Component* r);
		void changeState();
        CapsuleState* getState();
        //void setState(CapsuleState* c);
};

#endif
