#ifndef VACUUMMERLINENGINE_H
#define VACUUMMERLINENGINE_H

#include "Component.h"

class VacuumMerlinEngine : public Component
{
	public:
		void simulate();
		void test();
};

#endif
