#include "CapsuleArriving.h"

void CapsuleArriving::changeInternalState() {
	// TODO - implement CapsuleArriving::changeInternalState
	throw "Not yet implemented";
}
