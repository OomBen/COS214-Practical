#include "CapsuleArriving.h"
#include "CapsuleDocked.h"

void CapsuleArriving::changeInternalState(RocketCapsule* R) 
{
	R->state = new CapsuleDocked();
}
