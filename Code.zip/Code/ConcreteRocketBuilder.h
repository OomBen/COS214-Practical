#ifndef CONCRETEROCKETBUILDER_H
#define CONCRETEROCKETBUILDER_H

#include "Builder.h"
#include "ComponentCreator.h"

class ConcreteRocketBuilder : public Builder 
{
	private:
		ComponentCreator* merlinCreator;
		ComponentCreator* vacuumMerlinCreator;
		ComponentCreator* coreCreator;

	public:
		void getSpacecraft();
		void buildRocket();
};

#endif
