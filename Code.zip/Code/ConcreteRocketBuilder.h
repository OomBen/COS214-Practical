#ifndef CONCRETEROCKETBUILDER_H
#define CONCRETEROCKETBUILDER_H

#include "Builder.h"
#include "ComponentCreator.h"
#include "Component.h"
#include "CoreCreator.h"
#include "VacuumMerlinCreator.h"
#include "MerlinCreator.h"
#include "ComponentComposite.h"
#include "RocketCapsule.h"
#include "CrewDragon.h"
#include "CargoDragon.h"
#include "Fairing.h"

class ConcreteRocketBuilder : public Builder 
{
	private:
		ComponentCreator* merlinCreator;
		ComponentCreator* vacuumMerlinCreator;
		ComponentCreator* coreCreator;
		Component* rocket;
		RocketCapsule* capsule;

	public:
		Component* getSpacecraft();
		void buildFalcon9();
		void buildFalconHeavy();
		void constructCapsule();
};

#endif
