#include "Satellite.h"

void Satellite::setState(State* s) {
	// TODO - implement Satellite::setState
	throw "Not yet implemented";
}

void Satellite::changed() {
	// TODO - implement Satellite::changed
	throw "Not yet implemented";
}

Mediator* Satellite::getMediator() {
	return this->mediator;
}

void Satellite::setMediator(Mediator* m) {
	this->mediator = m;
}

void Satellite::requestStateChange() {
	// TODO - implement Satellite::requestStateChange
	throw "Not yet implemented";
}

void Satellite::attach(Observer o) {
	// TODO - implement Satellite::attach
	throw "Not yet implemented";
}

void Satellite::detatch(Observer o) {
	// TODO - implement Satellite::detatch
	throw "Not yet implemented";
}

void Satellite::notify() {
	// TODO - implement Satellite::notify
	throw "Not yet implemented";
}
