#ifndef STARLINKSATELITE_H
#define STARLINKSATELITE_H

#include "Satellite.h"
#include "SatelliteState.h"

class StarlinkSatelite : public Satellite 
{
	public:
		SatelliteState* getState();
		void setState(SatelliteState* s);
};

#endif
