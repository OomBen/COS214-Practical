#ifndef CORECREATOR_H
#define CORECREATOR_H

#include "ComponentCreator.h"

class CoreCreator : public ComponentCreator {


public:
	Component* factoryMethod();

	Component* clone(Component* C);
};

#endif
