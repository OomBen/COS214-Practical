#ifndef BUILDER_H
#define BUILDER_H

#include <iostream>
#include <string>

using namespace std;

#include "ConcreteRocketBuilder.h"

class Builder 
{
	public:
		virtual void buildFalcon9() = 0;
		virtual void buildFalconHeavy() = 0;
		virtual void constructCapsule() = 0;
		virtual void getSpacecraft() = 0;
};

#endif
