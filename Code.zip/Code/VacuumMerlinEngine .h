#ifndef VACUUMMERLINENGINE _H
#define VACUUMMERLINENGINE _H

#include "Component.h"

class VacuumMerlinEngine_ : public Component 
{
	public:
		void simulate();
		void test();
};

#endif
