#ifndef CREWDRAGON_H
#define CREWDRAGON_H

#include "RocketCapsule.h"

class CrewDragon : public RocketCapsule 
{
	private:
		string* passengers;

	public:
		CrewDragon(Component* r);
		void simulate();
		void test();
		string* getPassengers();
};

#endif
