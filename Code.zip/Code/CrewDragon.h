#ifndef CREWDRAGON_H
#define CREWDRAGON_H

#include "RocketCapsule.h"

class CrewDragon : public RocketCapsule 
{
	private:
		double payloadWeight;
		string* passengers;

	public:
		CrewDragon();
		void simulate();
		void test();
		double getPayloadWeight();
		string* getPassengers();
};

#endif
