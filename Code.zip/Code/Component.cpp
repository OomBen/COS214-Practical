#include "Component.h"

Component::Component(double c){
	cost = c;
}

void Component::add(Component* c) {
	// TODO - implement Component::add
	throw "Not yet implemented";
}

void Component::remove(int pos) {
	// TODO - implement Component::remove
	throw "Not yet implemented";
}

Component* Component::getComponent(int pos) {
	// TODO - implement Component::getComponent
	throw "Not yet implemented";
}

Component* Component::clone() {
	// TODO - implement Component::getComponent
	throw "Not yet implemented";
}

double Component::getCost() {
	return cost;
}
