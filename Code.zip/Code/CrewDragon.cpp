#include "CrewDragon.h"

CrewDragon::CrewDragon(): RocketCapsule()
{
	this->capsuleType = "Crew Dragon";
}

void CrewDragon::simulate() 
{
	//Might need to add more stuff to output here
	cout << capsuleType << " State: " << state->getState() << endl;
}

void CrewDragon::test() 
{
	// TODO - implement CrewDragon::test
	throw "Not yet implemented";
}

double CrewDragon::getPayloadWeight() 
{
	return payloadWeight;
}

string* CrewDragon::getPassengers() 
{
	return passengers;
}
