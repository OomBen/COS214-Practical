#include "Offline.h"

Offline::Offline(){}

void Offline::changeInternalState() 
{
	S->satelliteState = new Online();
}

string Offline::getType() 
{
	return "Offline";
}
