#include "Offline.h"

void Offline::changeInternalState() {
	// TODO - implement Offline::changeInternalState
	throw "Not yet implemented";
}

string Offline::getType() {
	// TODO - implement Offline::getType
	throw "Not yet implemented";
}
