#include "CapsuleOffline.h"
#include "CapsuleArriving.h"

void CapsuleOffline::changeInternalState(RocketCapsule* R) 
{
	R->state = new CapsuleArriving();
}
