#include "CapsuleOffline.h"

void CapsuleOffline::changeInternalState() {
	// TODO - implement CapsuleOffline::changeInternalState
	throw "Not yet implemented";
}
