/**
	@file StarlinkSatellite.h
	@brief	
		Participant - Concrete Product (Factory Method)
		Describes the attributes and methods of StarlinkSatellite objects.
	@author The 6 Musketeers
*/

#ifndef STARLINKSATELLITE_H
#define STARLINKSATELLITE_H

#include "Satellite.h"
#include "SatelliteState.h"

class StarlinkSatellite : public Satellite
{	
	public:
		/**
			@brief Constructor method for StarlinkSatellite objects. 
			Sets the ID to the integer sent in as a parameter.
			@param ID int
		*/
		StarlinkSatellite(int ID);

		StarlinkSatellite(Satellite* s);

		/**
			@brief Returns the state of the StarlinkSatellite.
			@return SatelliteState*
		*/
		SatelliteState* getState();

		/**
			@brief Sets the state of the Satellite to the SatelliteState sent in as a parameter.
			@param s SatelliteState
			@return void
		*/
		void setState(SatelliteState* s);

		/**
			@brief Calls the copy constructor in order to replicate current satellite.
			@return Satellite* 
		*/
		Satellite* clone();
};

#endif
