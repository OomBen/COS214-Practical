#include "MerlinEngine.h"

MerlinEngine::MerlinEngine(): Component(300000.0)
{

}

void MerlinEngine::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Merlin Engine | Status: Firing up | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void MerlinEngine::test() 
{
	
}

void MerlinEngine::fireMerlin(){
	cout << "Merlin engine ignites successfully" << endl;
}
