/**
	@file VacuumMerlinEngine.cpp
	@brief Implementation for VacuumMerlinEngine.h
*/

#include "VacuumMerlinEngineCreator.h"

Component* VacuumMerlinEngineCreator::factoryMethod() 
{
	return new VacuumMerlinEngine();
}

