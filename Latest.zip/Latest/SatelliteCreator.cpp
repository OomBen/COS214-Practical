/**
	@file SatelliteCreator.cpp
	@brief Implementation for SatelliteCreator.h
*/

#include "SatelliteCreator.h"

SatelliteCreator::SatelliteCreator(){
	count = 0;
}

Satellite* SatelliteCreator::factoryMethod() {
	return new StarlinkSatellite(count++);
}
