#include "CapsuleArriving.h"
#include "CapsuleDocked.h"

CapsuleArriving::CapsuleArriving(){}

string CapsuleArriving::getState(){
    return "Arriving";
}

CapsuleState* CapsuleArriving::handleChange()
{
    return new CapsuleDocked();
}

