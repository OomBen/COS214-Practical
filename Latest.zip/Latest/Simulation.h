/**
	@file Simulation.h
	@brief	
		Participant - Abstraction (Bridge)
		Describes the abstract class for running a simulation of a rocket launch.
	@author The 6 Musketeers
*/

#ifndef SIMULATION_H
#define SIMULATION_H

#include "SimulationState.h"
#include "Component.h"
#include "Fairing.h"
#include "Memento.h"
#include "Satellite.h"

class Simulation {

private:
	SimulationState* simulationState;	/**< The state of the Simulation. */
	Component* rocket;	/**< The rocket on which the Simulation is performed.*/
	RocketCapsule* capsule;	/**< The capsule on the rocket on which the Simulation is performed. */

public:
	/**
		@brief Constructor for Simulation objects. 
		Sets the simulationState, rocket and capsule variables.
		@param c Component* - The capsule on the rocket on which the Simulation is performed.
		@param r Component* - The rocket on which the Simulation is performed.
		@param s SimulationState* - The state of the Simulation.
	*/
	Simulation(RocketCapsule* c,Component* r, SimulationState* s);

	RocketCapsule* getCapsule();

	/**
		@brief Creates a Memento object and sets the state of the memento to the current simulationState.
		@return Memento*
	*/
	Memento* createMemento();

	/**
		@brief Sets the simulationState to the state of the memento.
		@param m Memento* - the Memento object storing the current simulation.
		@return void
	*/
	void restoreMemento(Memento* m);

	/**
		@brief Adds a call to the simulationState and calls the test() method on the rocket.
		@return void
	*/
	void staticFireTest();

	/**
		@brief Launches the rocket.
		IF FALCON9 ROCKET-
			-- Stage 1: single falcon 9 core with 9 Merlin engines
			-- Stage 2: single vacuum Merlin engine 
		IF FALCONHEAVY ROCKET-
			-- Stage 1: 3 Falcon Heavy cores with 27 Merlin engines
			-- Stage 2: single Merlin engine
		@return void
	*/
	void launch();

	/**
		@brief Pure virtual method to be implemented in all children classes.
		Tweaks the simulation on the rocket to represent a more realistic example of a real-world rocket simulation.
		@return void
	*/
	//virtual void tweakSimulation() = 0;

	/**
		@brief Prints a visual representation of the Simulation method calls.
		@return void
	*/
	void printSimulation();

	/**
	 	@brief Delivers Fairing capsule's payload (if Fairing is attached).
	 	@return void
	 */
	void jettisonFairing();

	/**
	 	@brief Seperates boosters from the rocket.
	 	@return void
	 */
	void separateBoosters();

	/**
	 	@brief Distributes satellites once in low-earth orbit.
	 	@return void
	 */
	void distributeSatellites();

	/**
	 	@brief Delivers crew once in low-earth orbit.
	 	@return void
	 */
	void deliverCrew();

	/**
	 	@brief Sends a string message from the receiving satellite to a receiving satellite.
	 	@return void
	 */
	void sendMessage(int sender,int reciever,string message);

	/**
		@brief Runs various launch methods from the simulationState consecutively in order to simulate launch event
		@return void
	*/
	void runSimulation();

	SimulationState* getState();

	void fireMerlin();

	void landBoosters();

	void fireVacuumMerlin();
};

#endif
