/**
	@file MerlinEngine.h
	@brief 
	Participant - ConcreteProduct (Factory Method), Concrete Implementor (Bridge).
	Defines the methods of the class that defines a Merlin engine.
	@author The 6 Musketeers
*/


#ifndef MERLINENGINE_H
#define MERLINENGINE_H

#include "Component.h"

class MerlinEngine : public Component
{
	public:
		/**
			@brief Constructor for MerlinEngine objects.
			Uses the Component (parent) constructor to initilize the object.
		*/
		MerlinEngine();

		/**
			@brief Starts the simulation for MerlinEngine objects.
			@return void
		*/
		void simulate();

		/**
			@brief Tests if the MerlinEngine meets all the requirements for a successful launch. 
			The requirements:
				- the cost must be >0
				- it must have a capsuleType
				- it must have a rocketType
			@return void
		*/
		void test();
		void fireMerlin();
};

#endif
