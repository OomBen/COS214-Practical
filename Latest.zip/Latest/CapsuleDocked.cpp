#include "CapsuleDocked.h"
#include "CapsuleOffline.h"
#include "CapsuleState.h"
#include "RocketCapsule.h"

CapsuleDocked::CapsuleDocked(){}

string CapsuleDocked::getState()
{
    return "Docked";
}

CapsuleState* CapsuleDocked::handleChange()
{
    return new CapsuleOffline();
}