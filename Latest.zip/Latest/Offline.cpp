#include "Offline.h"
#include "Online.h"

Offline::Offline(){}

string Offline::getType() 
{
	return "Offline";
}

SatelliteState* Offline::handleChange()
{
	return new Online();
}