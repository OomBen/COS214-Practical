#include "CapsuleDeparting.h"
#include "CapsuleArriving.h"
#include "RocketCapsule.h"

CapsuleDeparting::CapsuleDeparting(){}

string CapsuleDeparting::getState()
{
    return "Departing";
}

CapsuleState* CapsuleDeparting::handleChange()
{
    return new CapsuleArriving();
}
