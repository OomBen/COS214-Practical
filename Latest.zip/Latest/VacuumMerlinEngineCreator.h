/**
	@file VacuumMerlinEngineCreator.h
	@brief	
		Participant - ConcretePrototype (Prototpe), Concrete Implementor (Bridge), Concrete Product (Factory Method).
		Describes the attributes and methods of the class to create VacuumMerlinEngine objects.
	@author The 6 Musketeers
*/


#ifndef VACUUMMERLINENGINECREATOR_H
#define VACUUMMERLINENGINECREATOR_H

#include "ComponentCreator.h"
#include "Component.h"
#include "VacuumMerlinEngine.h"

class VacuumMerlinEngineCreator : public ComponentCreator 
{
	public:
		/** 
			@brief Factory Method to create VacuumMerlinEngine objects.
			@return Component*
		*/
		Component* factoryMethod();

		
		//Component* clone(Component* C);
};

#endif