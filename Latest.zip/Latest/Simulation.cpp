#include "Simulation.h"
#include "CapsuleDocked.h"
#include <stdio.h>
#include <unistd.h> // for usleep function

const char rocket[] =
"           _\n\
          /^\\\n\
          |-|\n\
          | |\n\
          |S|\n\
          |P|\n\
          |A|\n\
          |C|\n\
          |E|\n\
          | |\n\
          |X|\n\
         /| |\\\n\
        / | | \\\n\
       |  | |  |\n\
        `-\"\"\"-`\n\
";

void animateRocket(){
    for (int i = 0; i < 50; i ++) printf("\n"); // jump to bottom of console
    printf("%s", rocket);
    int j = 300000;
    for (int i = 0; i < 50; i ++) {
        usleep(j);                  // move faster and faster,
        j = (int)(j * 0.9);         // so sleep less each time
        printf("\n          | |");  // move rocket a line upward
    }
    printf("\n");
}

Simulation::Simulation(RocketCapsule* c,Component* r, SimulationState* s) {
	simulationState = s;
	rocket = r;
	capsule = c;
}

void Simulation::staticFireTest() {
	simulationState -> addCall("staticFireTest");
	rocket -> test();
}

void Simulation::launch() {
	cout << "Launching..." << endl;

	capsule->requestStateChange();		//change capsule state to CapsuleDeparting
	
	cout << "Here" << endl;

	sleep(2);
	animateRocket();
	rocketCost = 0;

	cout<< "Stage 1: "<<endl;
	if (simulationState->getRocketType() == "Falcon9") {
		//Stage 1: single falcon 9 core with 9 Merlin engines
		cout<<"\tSecond stage and payload almost in orbit..."<<endl;
		sleep(1);

		separateBoosters();
		//Stage 2: single vacuum Merlin engine 
		cout<<"Stage 2: "<<endl;
		cout<<"\tThe final single Vacuum Merlin engine provides the last kick and the Falcon 9 is in stage 2"<<endl;
		sleep(1);
		
		jettisonFairing();
		if(capsule != NULL){
			capsule->requestStateChange();	//change capsule state to CapsuleArriving
		}
		distributeSatellites();
		deliverCrew();	//changes capsule state to CapsuleDocked
	} else {
		//Stage 1: 3 Falcon Heavy cores with 27 Merlin engines
		cout<<"\tSecond stage and payload almost in orbit..."<<endl;
		sleep(1);

		separateBoosters();
		//Stage 2: single Merlin engine
		cout<<"Stage 2: "<<endl;
		cout<<"\tThe final single Merlin engine provides the last kick to get the FalconHEavy into a stable orbit"<<endl;
		sleep(1);

		jettisonFairing();
		if(capsule != NULL){
			capsule->requestStateChange();//change capsule state to CapsuleArriving
		}	
		distributeSatellites();
		deliverCrew();				//changes capsule state to CapsuleDocked
	}

	//simulationState -> addCall("launch");
	rocket -> simulate();
	if(capsule != NULL){
		capsule -> simulate();
	}
}

RocketCapsule* Simulation::getCapsule(){
	return capsule;
}

Memento* Simulation::createMemento () {
	Memento* m = new Memento();
	m->setState(simulationState);
	return m;
}

void Simulation::runSimulation () {
	for (auto &call : simulationState->getMethodCalls()) // access by reference to avoid copying
	{
		if(call == "staticFireTest"){
			staticFireTest();
		}
		else if(call == "jettisonFairing"){

		}
		else if(call == "separateBoosters"){
			
		}
		else if(call == "distributeSatellites"){
			
		}
		else if(call == "deliverCrew"){
			
		}
		else if (call.find("sendMessage") != string::npos) {
			
		}
	}
}

void Simulation::jettisonFairing(){
	simulationState -> addCall("jettisonFairing");
	if(simulationState->getCapsuleType() == "Fairing"){
		cout << "Releasing Fairing!" << endl;
		for(auto &s : simulationState->getSatellites()){
			s->requestStateChange();
		}
		sleep(1);
	}
}

void Simulation::separateBoosters(){
	simulationState -> addCall("separateBoosters");
	cout << "Separating Boosters!" << endl;
	Component* cores = rocket -> getComponent(0);
	cores -> separate();
}

void Simulation::distributeSatellites(){
	if(simulationState->getCapsuleType() == "Fairing"){
		if(capsule->getState()){

		}
		cout << "Distributing Satellites!" << endl;
		for(auto &s : simulationState->getSatellites()){
			s->requestStateChange();
		}
		sleep(1);
	}
}

void Simulation::deliverCrew(){
	string state = "";
	if(capsule != NULL){
		state = capsule->getState()->getState();
	}

	if(simulationState->getCapsuleType() == "Crew Dragon"){
		if(state == "Arriving"){
			cout << "Delivering crew to ISS." << endl;
			capsule->setState(new CapsuleDocked());
		}
		else{
			cout << "Capsule cannot deliver crew. Your capsule is a " << simulationState->getCapsuleType() << endl;
		}
	}
	else if(simulationState->getCapsuleType() == "Cargo Dragon"){
		if(state == "Arriving"){
			cout << "Delivering cargo to ISS." << endl;
			capsule->setState(new CapsuleDocked());
		}
		else{
			cout << "Capsule cannot deliver crew. Your capsule is a " << simulationState->getCapsuleType() << endl;
		}
	}
	else{
		cout << "A Fairing cannot deliver crew." << endl;
	}
	cout << "Capsule Status: " << capsule->getState()->getState() << endl;
}

void Simulation::printSimulation(){
	int count = 0;
	for (auto &call : simulationState->getMethodCalls()) // access by reference to avoid copying
	{
		cout << count << "|" << call << endl;
	}
}

void Simulation::sendMessage(int sender,int reciever,string message){
	cout << "HERE" << endl;
	if(simulationState->getCapsuleType() == "Fairing")
	{
		cout << "HEREAGAIN" << endl;
		cout << "Sending message!" << endl;
		Satellite* sSender = capsule -> getSatellite(sender);
		sSender -> sendMessage(reciever,message);

		string call = "sendMessage|"+to_string(sender)+"|"+to_string(reciever)+"|"+message;
		simulationState->addCall(call);
	}
}

SimulationState* Simulation::getState(){
	return simulationState;
}

void Simulation::fireMerlin(){
	if(simulationState->containsCall("fireMerlin")&&simulationState->containsCall("separateBoosters")){
		landBoosters();
	}
	else if(!simulationState->containsCall("separateBoosters")){
		simulationState -> addCall("fireMerlin");
		cout << "Firing all merlin engines!" << endl;
		Component* merlins = rocket -> getComponent(1);
		merlins -> fireMerlin();
	}
	else{
		cout << "Your rocket booster shoots for the stars... without you :(" << endl;
	}
}

void Simulation::landBoosters(){
	simulationState -> addCall("landBoosters");
	cout << "Landing boosters!" << endl;
	Component* cores = rocket -> getComponent(0);
	cores -> land();
	cout << "Total amount of money saved: " << to_string(cores->getSize()*32700000.0) << endl;
}

void Simulation::fireVacuumMerlin(){
	Component* vacuumMerlin = rocket -> getComponent(2);
	vacuumMerlin->fireVacuumMerlin();
}