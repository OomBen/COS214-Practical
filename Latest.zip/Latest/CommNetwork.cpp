#include "CommNetwork.h"
#include <iterator>

void CommNetwork::notify(int sender) 
{
	for (auto& satty : colleagueList)
	{
		string temp = "Satellite " + to_string(satty->getID()) + ": changed state to " +  satty->getState()->getType();
		satty->receiveMessage(sender, temp);
	}
}

void CommNetwork::sendMessage(int sender, int receiver, string msg){
	for(auto& s : colleagueList)
	{
		if(s->getID() == receiver){
			s->receiveMessage(sender, msg);
			return;
		}
	}
	cout << "The satellite with ID: " << receiver << " does not exist." << endl;
}