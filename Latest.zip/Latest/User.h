/**
	@file User.h
	@brief	
		Participant - Concrete Observer (Observer)
		Describes the attributes and methods of class that observes the state of Satellite objects.
	@author The 6 Musketeers
*/

#ifndef USER_H
#define USER_H

#include "Observer.h"
#include "SatelliteState.h"
#include "StarlinkSatellite.h"

class User : public Observer 
{
	private:
		SatelliteState* satelliteState; /**< The state of the Satellite it's observing. */
		StarlinkSatellite* subject; /**< The Satellite that it's observing.*/

	public:
		/**
			@brief Constructor for User objects.
			Sets the subject variable to the StarlinkSatellite passed in as a parameter.
			@param s StarlinkSatellite* - the StarlinkSatellite to set to.
		*/
		User(StarlinkSatellite* s);

		/**
			@brief Updates the satelliteState variable.
			@return void
		*/
		void update();
};

#endif
