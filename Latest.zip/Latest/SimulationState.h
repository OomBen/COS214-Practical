/**
	@file SimulationState.h
	@brief	
		Participant - ... (Memento)
		Describes the attributes and methods of a SimulationState object.
	@author The 6 Musketeers
*/

#ifndef SIMULATIONSTATE_H
#define SIMULATIONSTATE_H

#include "Component.h"
#include "Satellite.h"

#include <string>
#include <iostream>
#include <vector>

using namespace std;

class SimulationState {

private:
	Component* rocket;	/**< The rocket that the memento is capturing.*/
	string capsuleType;	/**< The type of capsule of the rocket.*/
	string rocketType;	/**< The type of the rocket that the memento is capturing.*/
	double payloadWeight; /**< The payloadWeight of the capsule.*/
	vector<Satellite*> satellites; /**< Vector of satellites on the rocket (if capsuleType == Fairing).*/
	vector<string> passengers; /**< Vector of the passengers on the rocket (if capsuleType == CrewDragon). */
	vector<string> methodCalls; /**< Vector of the method calls on the rocket in the simulation. */

public:
	/**
		@brief Constructor for SimulationState objects.
	*/
	SimulationState();	

	/**
		@brief Returns the capsule type of the rocket (CrewDragon, CargoDragon, Fairing).
		@return string
	*/
	string getCapsuleType();

	/**
		@brief Returns the rocket type of the rocket (Falcon9, FalconHeavy).
		@return string
	*/
	string getRocketType();

	/**
		@brief Returns the payloadWeight of the capsule.
		@return double
	*/
	double getPayloadWeight();

	/**
		@brief Returns the vector of satellites on the rocket (if capsuleType==Fairing).
		@return vector<Satellite*>
	*/
	vector<Satellite*> getSatellites();

	/**
		@brief Returns the vector of passengers on the rocket (if capsuleType==CrewDragon).
		@return vector<string>
	*/
	vector<string> getPassengers();
	/**
		@brief Returns the vector of methodCalls on the rocket.
		@return vector<string>
	*/
	vector<string> getMethodCalls();

	/**
		@brief Sets the capsuleType to the string passed in as a parameter.
		@param s string - the capsuleType to set to.
		@return void
	*/
	void setCapsuleType(string s);

	/**
		
Sets the rocketType tpo o the string passed in as a paramteeter.
		@param s string - the rocketType to set to.
		@return void	*/
	void setRocketType(string s);

	/**
		@brief Sets the payloadWeight to the string passed in as a parameter.
		@param d double - the value to set to.
		@return void e
	*/
	void setPayloadWeight(double d);

	/**
		@brief Sets the vector of Satellites to the vector passed in as a parameter.
		@param s vector<Satellite*> - the vector of Satellites to set to.
		@return void
	*/
	void setSatellites(vector<Satellite*> s);

	/**
		@brief Sets the vector of passengers (strings) to the vector passed in as a parameter.
		@param p vector<string> - the vector of strings to set to.
	*/
	void setPassengers(vector<string> p);

	/**
		@brief Adds a call to vector of methodCalls.
		@param c string - the method call to add to the vector.
		@return void
	*/
	void addCall(string c);

	/**
		@brief Checks if the methodCall vector contains the string passed in as a parameter.
		Returns true if it contains it. Returns false if it doesn't contain it.
		@param c string - the method call to check for.
		@return bool
	*/
	bool containsCall(string c);
};

#endif
