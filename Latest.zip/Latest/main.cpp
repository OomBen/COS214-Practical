/**
    @file main.cpp
    @brief Runs the program.
*/

// #include "Director.h"
// #include "Builder.h"
// #include "Simulation.h"
// #include "ConcreteRocketBuilder.h"
// #include "Caretaker.h"
#include "Facade.h"

#include "unitTest.cpp"
#include <gtest/gtest.h>

#include <stdio.h>
#include <unistd.h> // for usleep function

using namespace std;

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();

    Facade* f = new Facade();
    f->build();    
    f->fireMerlin();
    f->separateBoosters(); 
    f->fireMerlin();
    f->fireVacuumMerlin();
    f->useCommNetwork();
    f->storeSimulation();

    f->createAndRegisterUsers();


    //f->launch();
    //f->storeSimulation();

    //f->retrieveSimulation();
    //f->launch();



        //  THIS IS NOW HANDLED BY THE FACADE!

        // Builder * build = new ConcreteRocketBuilder();
        // Director * direct = new Director (build);
        // Simulation * simulate;

        // direct->construct();
        // simulate = direct->createSimulation("Falcon9");


        //  THIS IS NOW HANDLED BY THE FACADE!

        // Caretaker store;
        // store.storeMemento(simulate->createMemento());

        //     //do things then restore simulation using Memento
        // simulate->launch();

        // simulate->restoreMemento(store.retrieveMemento());

    delete f;

    return 0;
}

