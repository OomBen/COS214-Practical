/**
	@file Component.cpp
	@brief Implementation for Component.h
*/

#include "Component.h"
#include "Facade.h"

Component::Component(double c){
	cost = c;
}

void Component::add(Component* c) 
{
	//Virtual Function: called by inheriting composite
}

void Component::remove(int pos) 
{
	//Virtual Function: called by inheriting composite
}

Component* Component::getComponent(int pos) 
{
	return this;
}

// Component* Component::clone() 
// {
	// Component* newClone = new Component();
	// newClone->cost = this->cost;
	// newClone->rocketType = this->rocketType;
	// newClone->capsuleType = this->capsuleType;
	// return newClone;
// }

double Component::getCost() 
{
	return cost;
}

void Component::test()
{
	//Virtual Function: called by inheriting composite
}

void Component::simulate(){
	//Virtual Function: called by inheriting composite
}

void Component::separate(){
	//Virtual Function: called by inheriting composite
}

void Component::fireMerlin(){
	//Virtual Function: called by inheriting composite
}

void Component::land(){
	//Virtual Function: called by inheriting composite
}

int Component::getSize(){
	//Virtual Function: called by inheriting composite
}

void Component::fireVacuumMerlin(){

}
