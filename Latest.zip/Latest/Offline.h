/**
	@file Offline.h
	@brief 
	Participant - Concrete State (State).
	Describes the properties and methods of a Satellite in the 'Offline' state.
	@author The 6 Musketeers
*/

#ifndef OFFLINE_H
#define OFFLINE_H

#include "SatelliteState.h"

using namespace std;

class Offline: public SatelliteState 
{
	public:
		/**
			@brief Constructor for Offline objects.
		*/
		Offline();

		/**
			@brief Returns the type of state the satellite is currently in (Offline).
			@return string
		*/
		string getType();


		/**
			@brief Handles a change in state - sets the current state of the satellite to null.
			@return SatelliteState*
		*/
		SatelliteState* handleChange();
};

#endif
