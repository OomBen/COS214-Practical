/**
	@file Broadcasting.cpp
	@brief Implementation for Broadcasting.h
*/

#include "Broadcasting.h"
#include "Offline.h"

Broadcasting::Broadcasting(){}

string Broadcasting::getType() 
{
	return "Broadcasting";
}

SatelliteState* Broadcasting::handleChange()
{
	return new Offline();
}