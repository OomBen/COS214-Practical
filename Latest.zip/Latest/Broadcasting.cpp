#include "Broadcasting.h"
#include "Offline.h"

Broadcasting::Broadcasting(){}

string Broadcasting::getType() 
{
	return "Broadcasting";
}

SatelliteState* Broadcasting::handleChange()
{
	return new Offline();
}