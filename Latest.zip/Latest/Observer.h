/**
	@file Observer.h
	@brief 
	Participant - Observer (Observer)
	Defines the methods of the abstract class that observes the state of a satellite.
	@author The 6 Musketeers
*/


#ifndef OBSERVER_H
#define OBSERVER_H

#include <iostream>
#include <string>

using namespace std;

class Observer {

public:
	/**
		@brief Pure virtual function to be implemented in all the children classes.
		Updates the state of a satellite the class is currently observing.
		@return void
	*/
	virtual void update() = 0;
};

#endif
