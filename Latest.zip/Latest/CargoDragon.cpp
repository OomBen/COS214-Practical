/**
	@file CargoDragon.cpp
	@brief Implementation for CargoDragon.h
*/

#include "CargoDragon.h"

CargoDragon::CargoDragon(Component* r): RocketCapsule(r)
{
	this->capsuleType = "Cargo Dragon";
}

void CargoDragon::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Cargo Dragon | Status: " << state->getState() << " | Payload Weight: " << getPayloadWeight() << " | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl;
}

void CargoDragon::test() 
{
	
}
