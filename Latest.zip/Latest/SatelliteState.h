/**
	@file SatelliteState.h
	@brief	
		Participant - State (State)
		Describes the interface for the different states of a Satellite.
	@author The 6 Musekteers
*/

#ifndef SATELLITESTATE_H
#define SATELLITESTATE_H

#include <string>
#include <iostream>

using namespace std;

class SatelliteState 
{
	public:
		/**
			@brief Pure virtual function to be implemented in children classes.
			Returns the name of the current state of the Satellite.
			@return string
		*/
		virtual string getType() = 0;

		/**
			@brief Pure virtual function to be implemented in children classes.
			Handles a change in state.
			@return SatelliteState*
		*/
		virtual SatelliteState* handleChange() = 0;
};

#endif