/**
	@file Component.h
	@brief 
	Participant - Component (Decorator), Component (Composite), Client (Chain of Responsibility), Product (Builder), Product (Factory Method), Client (Prototype), Implementor (Brdige)
	Defines the attributes and methods for Component objects.
	@author The 6 Musketeers
*/

#ifndef COMPONENT_H
#define COMPONENT_H

#include <string>
#include <iostream>

using namespace std;

class Component 
{
	protected:
		double cost;	/**< The cost of the component */
		//string rocketType;	/**< The type of the rocket */
		//string capsuleType;	/**< The type of the capsule */

	public:
		/**
			@brief Constructor for Component objects. Takes in the cost as a parameter and initializes the cost variable.
			@param c double - the cost of the compoenent.
		*/
		Component(double c);
		
		/**
			@brief Virtual function that needs to be implemented in all the children classes.
			Starts the simulation for Component objects. 
			@return void
		*/
		virtual void simulate();

		/**
			@brief Virtual function that tests if the Component meets all the requirements for a successful launch. 
			The requirements depend on the type of Component.
			@return void
		*/
		virtual void test();

		/**
			@brief Adds a component to the rocket.
			@param c Component* - the Component to add to the rocket.
			@return void
		*/
		virtual void add(Component* c);

		/**
			@brief Virtual method that removes a component from the rocket based on its position.
			@param pos int - the position of the Component in the vector of components.
			@return void
		*/
		virtual void remove(int pos);

		/**
			@brief Virtual method that returns a component of the rocket based on its position.
			@param pos int - the position of the Component in the vector of components.
			@return Component*
		*/
		virtual Component* getComponent(int pos);



		//Component* clone();




		/**
			@brief Returns the cost of the component.
			@return double
		*/
		double getCost();

		virtual void separate();
		virtual void fireMerlin();
		virtual void land();
		virtual int getSize();
		virtual void fireVacuumMerlin();
};

static float rocketCost; /**< The total cost of the rocket.*/

#endif
