#include "Facade.h"
#include "ConcreteRocketBuilder.h"
#include "Director.h"
#include "Caretaker.h"

static Caretaker store;

Facade::Facade(){
    simulation = NULL;
}

Facade::~Facade(){
    if(simulation != NULL){
        delete simulation;
    }
    if(rocket != NULL){
        delete rocket;
    }
}

void Facade::launch(){
    test();
    //would you like to tweak 
        //retest if tweaked
    simulation->launch();
}

void Facade::test(){
    simulation->staticFireTest();
}

void Facade::build(){
    cout << "==============================================" << endl;
    Builder * build = new ConcreteRocketBuilder();
    Director * direct = new Director (build);
    Simulation * simulate;

    rocket = direct->construct();

    //would you like to test
        //would you like to tweak 
            //retest if tweaked

    simulation = direct->createSimulation();

    delete direct;
}

void Facade::storeSimulation(){
    store.storeMemento(simulation->createMemento());
}

void Facade::retrieveSimulation(){
    SimulationState* state = store.retrieveMemento()->getState();
	ConcreteRocketBuilder* rocketBuilder = new ConcreteRocketBuilder();
	if(state->getRocketType() == "Falcon9"){
        rocketBuilder->buildFalcon9();
	    rocket = rocketBuilder->getSpacecraft();
	}
	else{
        rocketBuilder->buildFalconHeavy();
		rocket = rocketBuilder->getSpacecraft();
	}

    RocketCapsule* capsule;
    if(state->getCapsuleType() == "Crew Dragon"){
        capsule = new CrewDragon(rocket);
        capsule->setPassengers(state->getPassengers());
    }
    else if(state->getCapsuleType() == "Cargo Dragon"){
        capsule = new CargoDragon(rocket);
    }
    else if(state->getCapsuleType() == "Fairing"){
        capsule = new Fairing(rocket);
        capsule->setSatellites(state->getSatellites());
    }

    simulation = new Simulation(capsule,rocket,state);
}

void Facade::separateBoosters(){
    simulation->separateBoosters();
}

void Facade::useCommNetwork(){
    if(simulation->getState()->getCapsuleType() == "Fairing"){
        cout << "How would you like to use the Satellite Communication Network?\n1: Send A Message To A Satellite \n2: Force Satellite Error State\n" << endl;
        
        string input = "";
        getline(cin, input);
        if (input == "1") {
            cout << "Input Receiver ID: ";
            input == "";
            getline(cin, input);
            int receiver = stoi(input);

            cout << "Input Sender ID: ";
            input == "";
            getline(cin, input);
            int sender = stoi(input);

            cout << "Input Message: ";
            input == "";
            getline(cin, input);
            string msg = input;

            //Code doesn't get here
            cout << "Before Send" << endl;
            simulation->sendMessage(sender, receiver, msg);
        }
        else if(input == "2"){
            cout << "Provide the ID of the satellite for which you wish to alter status: ";
            input == "";
            getline(cin, input);
            int id = stoi(input);

            cout << "Select a new status:\n[1]Broadcasting\n[2]Online\n[3]Offline" << endl;
            input == "";
            getline(cin, input);

            RocketCapsule* capsule = simulation->getCapsule();
            if(input == "1"){
                capsule->getSatellite(id)->setState(new Broadcasting());
            }
            else if(input == "2"){
                capsule->getSatellite(id)->setState(new Online());
            }
            else if(input == "3"){
                capsule->getSatellite(id)->setState(new Offline());
            }
        }

        cout << "Continue using the Satellite Communication Network?\n[1]Yes\n[2]No" << endl;
        input = "";
        getline(cin, input);
        if(input == "1"){
            useCommNetwork();
        }
    }
}

Component* Facade::getRocket(){
    return rocket;
}

void Facade::fireMerlin(){
    simulation->fireMerlin();
}

void Facade::fireVacuumMerlin(){
    simulation->fireVacuumMerlin();
}

//runBatch()
    //get from memento 
    //calls test()