/**
	@file Fairing.h
	@brief 
	Participant - Concrete Decorator (Decorator)
	Defines the attributes and methods for a RocketCapsule of type Fairing.
	@author The 6 Musketeers
*/

#ifndef FAIRING_H
#define FAIRING_H

#include "RocketCapsule.h"
#include "Satellite.h"

#include <vector>

class Fairing : public RocketCapsule 
{
	private:
		vector<Satellite*> satellites; /**< A vector of strings representing the satellites in the capsule.*/

	public:
		/**
			@brief Constructor for Fairing objects that takes in a rocket (Component) as a parameter and uses the RocketCapsule (parent) constructor to initialize the rocket object.
			@param r Component* - the rocket that the Fairing needs to be added to.
		*/
		Fairing(Component* r);

		/**
			@brief Starts the simulation for Fairing objects.
			@return void
		*/
		void simulate();
		/**
			@brief Tests if the Fairing meets all the requirements for a successful launch. 
			The requirements:
				- the cost must be >0
				- it must have a capsuleType
				- it must have a rocketType
			@return void
		*/
		void test();

		/**
			@brief Returns the vector of satellites.
			@return vector<Satellite*>
		*/
		vector<Satellite*> getSatellites();

		/**
			@brief Sets the vector of satellites to the vector passed in as a parameter.
			@param s vector<Satellite*> - the vector of Satellite objects to be set to.
		*/
		void setSatellites(vector<Satellite*> s);

		Satellite* getSatellite(int id);
};

#endif
