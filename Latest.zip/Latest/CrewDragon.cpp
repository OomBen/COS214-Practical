#include "CrewDragon.h"

CrewDragon::CrewDragon(Component* r): RocketCapsule(r)
{
	this->capsuleType = "Crew Dragon";
}

void CrewDragon::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Crew Dragon | Status: " << state->getState() << " | Payload Weight: " << this->getPayloadWeight() << " | Passengers: " << passengers.size() << " | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl;
}

void CrewDragon::test() 
{
	
}

vector<string> CrewDragon::getPassengers() 
{
	return passengers;
}

void CrewDragon::setPassengers(vector<string> temp) {
	passengers = temp;
}
