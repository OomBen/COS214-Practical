/**
	@file Satellite.h
	@brief 
		Participant - ConcreteSubject (Observer), Colleague (Mediator), Context (State), Product (Factory Method).
		Describes the properties and methods of a Satellite object.
	@author The 6 Muskateers
*/


#ifndef SATELLITE_H
#define SATELLITE_H

#include <iostream>
#include <vector>
#include <string>

#include "Mediator.h"
#include "Observer.h"
#include "Offline.h"

using namespace std;
class SatelliteState;
class Mediator;
class Satellite 
{
	protected:
		SatelliteState* satelliteState;		/**< The state of the Satellite*/
		Mediator* mediator;					/**< The mediator object that controls the communication between satellites.*/
		vector<Observer*> observerList;		/**< The list of observers that are observing and monitoring the satellite.*/
		int ID;								/**< The integer used to uniquely identify the satellite.*/

	public:
		/**
			@brief Constructor for Satellite objects. 
			Sets the ID to the value sent in as a parameter.
			@param ID int - the id of the satellite.
		*/
		Satellite(int ID);

		/**
			@brief Destructor for Satellite objects.
		*/
		~Satellite();

		/**
			@brief Notifies the other satellites that the state of the current satellite has changed by calling the notify() method on the mediator object.
			@return void
		*/
		void changed();



		//Mediator* getMediator();


		/**
			@brief Getter method that returns the ID of the Satellite object.
			@return int
		*/
		int getID();

		/**
			@brief Sends a string message to a particular satellite, based on ID.
			@param id int - The ID of the satellite.
			@param msg string - The message that needs to be printed.
			@return void
		*/
		void sendMessage(int id, string msg);

		/**
			@brief Prints out the state and ID of the changed colleague.
			@param msg string - the message that needs to be printed.
			@return void
		*/
		void receiveMessage(int id, string msg);

		/**
			@brief Setter function to set the mediator to the Mediator object passed in as a parameter.
			@param m Mediator* - the Mediator object to be set to.
			@return void
		*/
		void setMediator(Mediator* m);

		Mediator* getMediator();

		/**
			@brief Changes the state of the satellite by calling setState().
			Notifies the mediators by calling changed().
			Notifies the observers by calling notify().
			@return void
		*/
		void requestStateChange();

		/**
			@brief Registers an observer with the Satellite.
			Adds the Observer sent in as a parameter to the observerList.
			@param o Observer* - the Observer to be registered.
			@return void
		*/
		void attach(Observer* o);

		/**
			@brief Deregisters an observer from the Satellite.
			Removes the Observer sent in as a paramter from the observerList.
			@param o Observer* - the Observer to be deregistered.
			@return void
		*/
		void detach(Observer* o);

		/**
			@brief Notifies all the observers of the state change.
			@return void
		*/
		void notify();

		/**
			@brief Virtual function that returns the state of the Satellite.
			@return SatelliteState*
		*/
		virtual SatelliteState* getState();

		/**
			@brief Sets the state of the Satellite to the SatelliteState sent in as a parameter.
			@param s SatelliteState* - the state to be set to.
			@return void
		*/
		void setState(SatelliteState* s);

		virtual Satellite* clone(){ return NULL;}
};

#endif
