/**
	@file ComponentCreator.h
	@brief 
	Participant - Creator (Factory Method), Prototype (Prototype).
	Defines the interface creating the Merlin, Vacuum Merlin and Core Engines 
	@author The 6 Musketeers
*/

#ifndef COMPONENTCREATOR_H
#define COMPONENTCREATOR_H

#include "Component.h"

class ComponentCreator 
{
	private:
		Component* component;	/**< A Component object that the ComponentCreator class will create */

	public:
		/**
			@brief Virtual functon to be implemented in all the children classes.
			Factory method to create different types of engines.
			@return Component*
		*/
		virtual Component* factoryMethod() = 0;



		//virtual Component* clone(Component* C) = 0;
};

#endif
