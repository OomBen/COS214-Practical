#include "StarlinkSatellite.h"

StarlinkSatellite::StarlinkSatellite(int ID):Satellite(ID)
{
	//Nothing to do here: Construction logic implemented in parent
}

StarlinkSatellite::StarlinkSatellite(Satellite* s) : Satellite(s->getID()){
	satelliteState = s->getState();
	mediator = s->getMediator();
	observerList = observerList;
	ID = s->getID();
}

SatelliteState* StarlinkSatellite::getState() 
{
	return this->satelliteState;
}

void StarlinkSatellite::setState(SatelliteState* s) 
{
	this->satelliteState = s;
}

Satellite* StarlinkSatellite::clone(){
	return new StarlinkSatellite(this);
}