#include "Director.h"

Director::Director(Builder* b) 
{
	this->builder = b;
}

Director::~Director(){
	if(builder != NULL){
		delete builder;
	}
}

Component* Director::construct() 
{
	string input = "";
	do {
		cout<<"What kind of rocket would you like to build?\n1: Falcon 9\n2: Falcon Heavy\n";
		getline(cin, input);
	} while (input!="1" &&input!= "2");
	if (input=="1") {
		cout<<"Creating a Falcon 9...\n";
		type = "Falcon 9";
		builder->buildFalcon9();
	} else {
		cout<<"Creating a Falcon Heavy...\n";
		type = "Falcon Heavy";
		builder->buildFalconHeavy();
	}

	input = "";
	do {
		cout<<"Would you like to add a capsule?\n1: Yes\n2: No\n";
		getline(cin, input);
		if (input == "1") {
			constructCapsule();
		}
	} while (input!= "2"&&input!="1");

	return this->builder->getSpacecraft();
}

void Director::constructCapsule() {
	// if (simulationState->getRocketType() != "Falcon9")
    //     {
    //         cout << "A Fairing cannot be attached to a Falcon Heavy Rocket.\n";
    //         return;
    //     }
	bool flag = false;
	string input = "";
	
	do {
		flag = false;
		cout<<"What kind of capsule would you like to build?\n1: Crew Dragon\n2: Cargo Dragon\n3: Fairing (You must have a Falcon 9 in order to build a fairing)\n";
		getline(cin, input);
		if ((input=="3" && type=="Falcon 9")||input=="2"||input=="1") {
			flag = true;
		}
	} while((input!="1" &&input!= "2" &&input!="3")||!flag);
	
	if (input=="1") {
		cout<<"Creating a Crew Dragon...\n";
		builder->constructCapsule("Crew Dragon");
	} else if (input=="2") {
		cout<<"Creating a Cargo Dragon...\n";
		builder->constructCapsule("Cargo Dragon");
	} else {
		//must be a Falcon 9
		cout<<"Creating a Fairing...\n";
		builder->constructCapsule("Fairing");
	}
}

Simulation* Director::createSimulation(){
	return builder->createSimulation();
}

