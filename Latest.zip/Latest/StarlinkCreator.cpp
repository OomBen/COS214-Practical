/**
	@file StarlinkCreator.cpp
	@brief Implementation for StarlinkCreator.h
*/

#include "StarlinkCreator.h"

StarlinkCreator::StarlinkCreator() : SatelliteCreator(){
	this->IDcount = 0;
}

Satellite* StarlinkCreator::factoryMethod() {
	return new StarlinkSatellite(IDcount);
	++IDcount;
}
