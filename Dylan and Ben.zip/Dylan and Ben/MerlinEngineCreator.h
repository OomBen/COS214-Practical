/**
	@file MerlinEngineCreator.h
	@brief 
	Participant - ConcreteCreator (Factory Method), ConcretePrototype (Prototype)
	Defines the methods of the class that defines a Merlin engine.
	@author The 6 Muskateers
*/


#ifndef MERLINENGINECREATOR_H
#define MERLINENGINECREATOR_H

#include "ComponentCreator.h"
#include "Component.h"
#include "MerlinEngine.h"

class MerlinEngineCreator : public ComponentCreator 
{
	public:
		Component* factoryMethod();
		//Component* clone(Component* C);
};

#endif
