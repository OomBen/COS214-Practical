/**
	@file Offline.h
	@brief 
		Participant - Concrete State (State).
		Describes the properties and methods of a Satellite in the 'Offline' state.
	@author The 6 Muskateers
*/

#ifndef OFFLINE_H
#define OFFLINE_H

#include "SatelliteState.h"

using namespace std;

class Offline: public SatelliteState 
{
	public:
		/**
			@brief Constructor for the Offline object
		*/
		Offline();

		/**
			@brief Returns a string with the state name.			
			@return string
		*/
		string getType();


		/**
			@brief Handles a change in state - sets the current state of the satellite to 'Online'.
			@return SatelliteState*
		*/
		SatelliteState* handleChange();
};

#endif
