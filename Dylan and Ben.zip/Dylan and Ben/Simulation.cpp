#include "Simulation.h"

Simulation::Simulation(Component* c,Component* r, SimulationState* s) {
	simulationState = s;
	rocket = r;
	capsule = c;
}

void Simulation::staticFireTest() {
	simulationState -> addCall("staticFireTest");
	rocket -> test();
}

void Simulation::launch() {
	simulationState -> addCall("launch");
	rocketCost = 0;
	rocket -> simulate();
	capsule -> simulate();
}

Memento* Simulation::createMemento () {
	Memento* m = new Memento();
	m->setState(simulationState);
	return m;
}

void Simulation::restoreMemento(Memento* m) {
	simulationState = m->getState();
}

void Simulation::printSimulation(){
	int count = 0;
	for (auto &call : simulationState->getMethodCalls()) // access by reference to avoid copying
	{
		cout << count << "|" << call << endl;
	}
}
