#ifndef USER_H
#define USER_H

#include "Observer.h"
#include "SatelliteState.h"
#include "StarlinkSatellite.h"

class User : public Observer 
{
	private:
		SatelliteState* satelliteState;
		StarlinkSatellite* subject;

	public:
		User(StarlinkSatellite*);
		void update();
};

#endif
