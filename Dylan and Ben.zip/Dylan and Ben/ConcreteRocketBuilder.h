/**
	@file ComponentRocketBuilder.h
	@brief 
	Participant - Concrete Builder (Builder)
	Defines the methods and attributes of the class that builds a rocket.
	@author The 6 Muskateers
*/

#ifndef CONCRETEROCKETBUILDER_H
#define CONCRETEROCKETBUILDER_H

#include "Builder.h"
#include "ComponentCreator.h"
#include "CoreCreator.h"
#include "VacuumMerlinEngineCreator.h"
#include "MerlinEngineCreator.h"
#include "ComponentComposite.h"
#include "RocketCapsule.h"
#include "CrewDragon.h"
#include "CargoDragon.h"
#include "Fairing.h"
#include "SimulationState.h"
#include "SatelliteCreator.h"
#include "StarlinkCreator.h"

#include "Falcon9Simulation.h"
#include "FalconHeavySimulation.h"

#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

class ConcreteRocketBuilder : public Builder 
{
	private:
		ComponentCreator* merlinCreator; /**< ComponentCreator for merlin engines */
		ComponentCreator* vacuumMerlinCreator; /**< ComponentCreator for vacuum merlin engines */
		ComponentCreator* coreCreator; /**< ComponentCreator for core engines */
		Component* rocket;	/**< Component object for the rocket */
		RocketCapsule* capsule; /**< RocketCapsule object for the capsule */
		SimulationState* simulationState; /**< SimulationState object for the simulation state of the rocket*/

	public:
		/**
			@brief Constructor for ConcreteRocketBuilder objects.
		*/
		ConcreteRocketBuilder();

		/**
			@brief Returns the current spacecraft/rocket.
			@return Component*
		*/
		Component* getSpacecraft();

		/**
			@brief Builds the Falcon9 rocket. 
			Adds the core, merlin engine and vacuum merlin engine components.
			@return void
		*/
		void buildFalcon9();

		/**
			@brief Builds the FalconHeavy rockey.
			Adds the core, merlin engine and vacuum merlin engine components.
			@return void
		*/
		void buildFalconHeavy();

		/**
			@brief Creates a new capsule. 
			The capsule can be either a CrewDragon, CargoDragon or Fairing. 
			The capsule is constructed differently based on the capsule type.
			@param type string
			@return void
		*/
		void constructCapsule(string type);

		/**
			@brief Creates a new simulation based on the capsule, rocket and simulation state.
			@return Simulation*
		*/
		Simulation* createSimulation(string t);
};

#endif
