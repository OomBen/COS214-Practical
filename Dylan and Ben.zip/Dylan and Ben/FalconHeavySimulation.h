/**
	@file FalconHeavySimulation.h
	@brief 
	Participant - Refined Abstraction (Bridge)
	Defines the methods of the class used to tweak the simulation on a FalconHeavy Rocket.
	@author The 6 Muskateers
*/


#ifndef FALCONHEAVYSIMULATION_H
#define FALCONHEAVYSIMULATION_H

#include "Simulation.h"

class FalconHeavySimulation : public Simulation {


public:
	FalconHeavySimulation(Component* c,Component* r, SimulationState* s);

	/** 
		@brief Tweaks the simulation on the FalconHeavy rocket to represent a more realistic example of a real-world rocket simulation.
		@return void
	*/
	void tweakSimulation();
};

#endif
