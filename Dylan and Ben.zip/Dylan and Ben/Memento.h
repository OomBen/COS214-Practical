/**
	@file Memento.h
	@brief 
	Participant - Memento (Memento)
	Defines the methods of the class that stores the state of the simulation of a rocket.
	@author The 6 Muskateers
*/

#ifndef MEMENTO_H
#define MEMENTO_H

#include <iostream>
#include <string>

#include "SimulationState.h"

using namespace std;

class Memento 
{
	private:
		SimulationState* state; /**< SimulationState object that store the state of the simulation*/

	public:
		/**
			@brief Returns the current state of the simulation.
			@return SimulationState*
		*/
		SimulationState* getState();

		/**
			@brief Sets the simulationState the the object passed in as a paramter.
			@param c SimulationState*
			@return void
		*/
		void setState(SimulationState* c);

		/**
			@brief Simple destructor for the Memento class.
		*/
		~Memento();
};

#endif
