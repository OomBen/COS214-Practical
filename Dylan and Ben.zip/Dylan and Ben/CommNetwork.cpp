#include "CommNetwork.h"
#include <iterator>

void CommNetwork::notify(Satellite* colleague) 
{
	for (Satellite* satty : colleagueList)
	{
		string temp = "Satellite " + to_string(satty->getID()) + ": changed state to " +  satty->getState()->getType();
		satty->receiveStateInfo(temp);
	}

	// vector<Satellite*>::iterator it = colleagueList.begin();
	// while ((it != colleagueList.end())) {
	// 	string temp = "Satellite " + to_string(colleague->getID()) + ": changed state to " +  colleague->getState()->getType();
	// 	(*it)->receiveStateInfo(temp);
	// 	++it;
	// }
}
