/**
	@file Director.h
	@brief 
	Participant - Director (Builder)
	Defines the attributes and methods for the class that constructs rockets using the Builder interface.
	@author The 6 Muskateers
*/

#ifndef DIRECTOR_H
#define DIRECTOR_H

#include <string>
#include <iostream>

#include "Builder.h"

using namespace std;

class Director 
{
	private:
		Builder* builder;	/**< Builder object that hold the rocket builder*/

	public:
		/**
			@brief Constructor that takes in a builder object and initializes the builder variable.
			@param b Builder*
		*/
		Director (Builder* b);

		/**
			@brief Constructs the rocket. 
			User will have the choice of creating a Falcon9 or FalconHeavy rocket.
			User will have the option of adding a capsule to the rocket. (Capsule can be a CrewDragon, CargoDragon or Fairing).
			@return Component*
		*/
		Component* construct();

		/**
			@brief Creates a new capsule of types CrewDragon, CargoDragon or Fairing.
			@return void
		*/
		void constructCapsule();

		/**
			@brief Creates a new simulation
			@return Simulation* 
		*/
		Simulation* createSimulation(string rocketType);
};
#endif //DIRECTOR_H