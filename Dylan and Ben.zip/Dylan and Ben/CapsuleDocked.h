/**
	@file CapsuleDocked.h
	@brief	
		Participant - Concrete State (State)
		Describes the methods of a Capusle that is in a 'docked' state.
	@author The 6 Musakteers
*/
#ifndef CAPSULEDOCKED_H
#define CAPSULEDOCKED_H

#include "CapsuleState.h"

using namespace std;

class CapsuleDocked : public CapsuleState 
{
	public:

		/**
			@brief Constructor for CapsuleDocked objects.
		*/
		CapsuleDocked();

		/**
			@brief Returns the state that the capsule is currently in (Docked).
			@return string
		*/
		string getState();

		/**
			@brief Handles a change in state - sets the state of the current capsule to 'offline'.
			@return CapsuleState*
		*/
		CapsuleState* handleChange();
};

#endif
