#include "Broadcasting.h"
#include "Offline.h"

Broadcasting::Broadcasting(){}

string Broadcasting::getType() 
{
	return "Broadcasting";
}

SatelliteState* Broadcasting::handleChange()
{
	return new Offline();
}
// void RedState::handleChange(Context* c) {
//     c->setState(new GreenState());
// }