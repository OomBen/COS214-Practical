#include "Component.h"

Component::Component(double c){
	cost = c;
}

void Component::add(Component* c) 
{
	//Virtual Function: called by inheriting composite
}

void Component::remove(int pos) 
{
	//Virtual Function: called by inheriting composite
}

Component* Component::getComponent(int pos) 
{
	return this;
}

// Component* Component::clone() 
// {
	// Component* newClone = new Component();
	// newClone->cost = this->cost;
	// newClone->rocketType = this->rocketType;
	// newClone->capsuleType = this->capsuleType;
	// return newClone;
// }

double Component::getCost() 
{
	return cost;
}

void Component::test()
{
	//Virtual Function: called by inheriting composite
}

void Component::simulate(){
	//Virtual Function: called by inheriting composite
}
