/**
	@file Mediator.h
	@brief 
	Participant - Mediator (Mediator)
	Defines the methods of the interface that enables communication between the different satellites.
	@author The 6 Muskateers
*/


#ifndef MEDIATOR_H
#define MEDIATOR_H

#include <string>
#include <iostream>

#include "Satellite.h"
class Satellite;
using namespace std;

class Mediator {

public:
	/**
		@brief Pure virtual function to be implemented in all children.
		Notifies all the satellites (colleagues) if the state of the one of the satellites have changed.
		@param colleague Satellite*
		@return void
	*/
	virtual void notify(Satellite* colleague) = 0;
};

#endif
