/**
	@file Falcon9Simulation.h
	@brief 
	Participant - Refined Abstraction (Bridge)
	Defines the methods of the class used to tweak the simulation on a Falcon9 Rocket.
	@author The 6 Muskateers
*/

#ifndef FALCON9SIMULATION_H
#define FALCON9SIMULATION_H

#include "Simulation.h"

class Falcon9Simulation : public Simulation {


public:
	Falcon9Simulation(Component* c,Component* r, SimulationState* s);
	
	/** 
		@brief Tweaks the simulation on the Falcon9 rocket to represent a more realistic example of a real-world rocket simulation.
		@return void
	*/
	void tweakSimulation();
};

#endif
