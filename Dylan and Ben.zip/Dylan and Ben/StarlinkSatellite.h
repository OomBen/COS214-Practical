#ifndef STARLINKSATELLITE_H
#define STARLINKSATELLITE_H

#include "Satellite.h"
#include "SatelliteState.h"

class StarlinkSatellite : public Satellite
{	
	public:
		StarlinkSatellite(int ID);
		SatelliteState* getState();
		void setState(SatelliteState* s);
};

#endif
