#include "VacuumMerlinEngineCreator.h"

Component* VacuumMerlinEngineCreator::factoryMethod() 
{
	return new VacuumMerlinEngine();
}

