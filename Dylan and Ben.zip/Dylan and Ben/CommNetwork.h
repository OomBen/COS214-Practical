/**
	@file CommNetwork.h
	@brief 
	Participant - Concrete Mediator (Mediator)
	Defines the attributes and methods for the class used for communication between the satellites.
	@author The 6 Muskateers
*/


#ifndef COMMNETWORK_H
#define COMMNETWORK_H

#include <string>
#include <vector>
#include "Mediator.h"
#include "Satellite.h"

class CommNetwork : public Mediator {
	public:
		vector<Satellite*> colleagueList; /**< A vector of Satellite objects representing the colleagues of the Mediator pattern */
		
	public:
		/**
			@brief Notifies all the satellites (colleagues) if the state of the one of the satellites have changed.
			@param colleague Satellite*
			@return void
		*/
		void notify(Satellite* colleague);
};

#endif