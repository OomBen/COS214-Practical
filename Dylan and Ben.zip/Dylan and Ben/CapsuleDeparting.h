/**
	@file CapsuleDeparting.h
	@brief	
		Participant - Concrete State (State)
		Describes the methods of a Capusle that is in a 'departing' state.
	@author The 6 Musakteers
*/

#ifndef CAPSULEDEPARTING_H
#define CAPSULEDEPARTING_H

#include "CapsuleState.h"

using namespace std;

class CapsuleDeparting : public CapsuleState 
{
	public:

		/**
			@brief Constructor for CapsuleDeparting objects.
		*/
		CapsuleDeparting();

		/**
			@brief Returns the state that the capsule is currently in (Departing).
			@return string
		*/
		string getState();

		/**
			@brief Handles a change in state - sets the state of the current capsule to 'arriving'.
			@return CapsuleState*
		*/
		CapsuleState* handleChange();
};

#endif
