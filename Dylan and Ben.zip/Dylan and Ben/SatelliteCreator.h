#ifndef SATELLITECREATOR_H
#define SATELLITECREATOR_H

#include <iostream>
#include <string>

#include "StarlinkSatellite.h"

using namespace std;

class SatelliteCreator 
{
	private:
		int count;

	public:
		SatelliteCreator();
		Satellite* factoryMethod();

};

#endif
