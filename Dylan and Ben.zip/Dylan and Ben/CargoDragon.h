/**
	@file CargoDragon.h
	@brief 
	Participant - Concrete Decorator (Decorator)
	Defines the attributes and methods for a RocketCapsule that carries Cargo.
	@author The 6 Muskateers
*/

#ifndef CARGODRAGON_H
#define CARGODRAGON_H

#include "RocketCapsule.h"

class CargoDragon : public RocketCapsule 
{
	public:
		/**
			@brief Constructor for CargoDragon objects. 
			Takes in a rocket as a parameter and uses the RocketCapsule(parent) constructor to initialize the rocket variable.
		*/
		CargoDragon(Component*);

		/**
			@brief Starts the simulation for CargoDragon objects.
			@return void
		*/
		void simulate();

		/**
			@brief Tests if the CargoDragon meets all the requirements for a successful launch. 
			The requirements:
				- the cost must be >0
				- it must have a capsuleType
				- it must have a rocketType
			@return void
		*/
		void test();
};

#endif