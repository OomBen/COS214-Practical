/**
	@file CoreCreator.h
	@brief 
	Participant - Concrete Creator (Factory Method)
	Defines the methods and attributes of the class that builds Falcon Core engines
	@author The 6 Muskateers
*/

#ifndef CORECREATOR_H
#define CORECREATOR_H

#include "ComponentCreator.h"
#include "Component.h"
#include "FalconCore.h"

//Factory Method Concrete Creator
class CoreCreator : public ComponentCreator 
{
	public:
		/**
			@brief Factory method to create a new FalconCore object 
			@return Component* 
		*/
		Component* factoryMethod();

		/**
			@brief Clone method to create a copy of a FalconCore object / Component
		*/
		//Component* clone(Component* C);
};

#endif
