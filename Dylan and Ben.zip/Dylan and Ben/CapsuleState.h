/**
	@file CapsuleState.h
	@brief	
		Participant - State (State)
		Describes the interface for the different states of a capsule.
	@author The 6 Musakteers
*/


#ifndef CAPSULESTATE_H
#define CAPSULESTATE_H

#include "RocketCapsule.h"

using namespace std;
class CapsuleState 
{
	public:
		/**
			@brief Pure virtual function to be implemented in children classes.
				The function returns the current state of the capsule (Arriving/Departing/Docked/Offline).			
			@return string
		*/
		virtual string getState() = 0;

		/**
			@brief Pure virtual function to be implemented in children classes.
				Handles the change in state by setting the state of the capsule to a new state.			
			@return string
		*/
		virtual CapsuleState* handleChange() = 0;
};



#endif
