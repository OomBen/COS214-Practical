#include "ComponentComposite.h"

ComponentComposite::ComponentComposite(): Component(0){
	
}

void ComponentComposite::simulate() {
	for (auto c: components){
		c -> simulate();
	}
}

void ComponentComposite::test() {
	for (auto c: components){
		c -> test();
	}
}

void ComponentComposite::add(Component* c) {
	cost += c -> getCost();
	components.push_back(c);
}

void ComponentComposite::remove(int pos) {
	//need to make iterator

	//components.erase(vec.begin() + pos);

	//NOT SURE IF THIS WORKS!!!
	int i=0;
	vector<Component*>::iterator it = components.begin();
	while ((it != components.end())&&i<pos) {
		if (i==pos) {
			components.erase(it);
		}
		++it;
		i++;
	}
	
}

Component* ComponentComposite::getComponent(int pos) {
	return components[pos];
}