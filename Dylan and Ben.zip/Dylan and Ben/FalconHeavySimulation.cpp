#include "FalconHeavySimulation.h"

FalconHeavySimulation::FalconHeavySimulation(Component* c,Component* r, SimulationState* s): Simulation(c,r,s)
{

}

void FalconHeavySimulation::tweakSimulation() {
	// TODO - implement FalconHeavySimulation::tweakSimulation
	throw "Not yet implemented";
}
