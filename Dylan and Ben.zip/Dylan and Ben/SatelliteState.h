/**
	@file SatelliteState.h
	@brief	
		Participant - State (State)
		Describes the interface for the different states of a satellite.
	@author The 6 Musakteers
*/

#ifndef SATELLITESTATE_H
#define SATELLITESTATE_H

#include <string>
#include <iostream>

using namespace std;

class SatelliteState 
{
	public:
		/**
			@brief Returns a string with the current state name. Implemented in derived classes.		
			@return string
		*/
		virtual string getType() = 0;

		/**
			@brief Handles a change in satellite state. Implemented in derived classes.
			@return SatelliteState*
		*/
		virtual SatelliteState* handleChange() = 0;
};

#endif