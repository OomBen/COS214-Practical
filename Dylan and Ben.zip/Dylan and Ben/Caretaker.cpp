#include "Caretaker.h"

Caretaker::Caretaker() {
	store = NULL;
}

Caretaker::~Caretaker(){
	if(store != NULL){
		delete store;
	}
}

void Caretaker::storeMemento(Memento* m) {
	store = m;
}

Memento* Caretaker::retrieveMemento() {
	return store;
}
