#include "MerlinEngineCreator.h"

Component* MerlinEngineCreator::factoryMethod() 
{
	return new MerlinEngine();
}

