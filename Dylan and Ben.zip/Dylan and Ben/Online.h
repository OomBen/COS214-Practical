/**
	@file Online.h
	@brief 
		Participant - Concrete State (State).
		Describes the properties and methods of a Satellite in the 'Online' state.
	@author The 6 Muskateers
*/


#ifndef ONLINE_H
#define ONLINE_H

#include "SatelliteState.h"

using namespace std;

class Online : public SatelliteState 
{
	public:

		/**
			@brief  Constructor for the Online object.
		*/
		Online();

		/**
			@brief Returns a string with the state name.
			@return string
		*/
		string getType();

		/**
			@brief Handles a change in state - sets the current state of the satellite to 'Broadcasting'.
			@return SatelliteState*
		*/
		SatelliteState* handleChange();
};

#endif
