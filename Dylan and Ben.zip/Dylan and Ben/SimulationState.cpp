#include "SimulationState.h"
SimulationState::SimulationState()
{

}

string SimulationState::getCapsuleType() {
	return this->capsuleType;
}

string SimulationState::getRocketType() {
	return this->rocketType;
}

double SimulationState::getPayloadWeight() {
	return this->payloadWeight;
}

vector<Satellite*> SimulationState::getSatellites() {
	return this->satellites;
}

vector<string> SimulationState::getPassengers() {
	return this->passengers;
}

vector<string> SimulationState::getMethodCalls() {
	return this->methodCalls;
}

void SimulationState::setCapsuleType(string c){
	capsuleType = c;
}

void SimulationState::setRocketType(string s){
	rocketType = s;
}

void SimulationState::setPayloadWeight(double p){
	payloadWeight = p;
}

void SimulationState::setSatellites(vector<Satellite*> s){
	satellites = s;
}

void SimulationState::setPassengers(vector<string> p){
	passengers = p;
}

void SimulationState::addCall(string c){
	methodCalls.push_back(c);
}

