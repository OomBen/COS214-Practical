/**
	@file FalconCore.h
	@brief 
	Participant - ConcreteComponent (Decorator), Leaf (Composite), ConcreteProduct (Factory Method), Concrete Implementor (Bridge)
	Defines the methods of the class that defines a FalconCore engine.
	@author The 6 Muskateers
*/

#ifndef FALCONCORE_H
#define FALCONCORE_H

#include "Component.h"

class FalconCore : public Component 
{
	public:
		/**
			@brief Constructor for FalconCore objects.
		*/
		FalconCore();

		/**
			@brief Starts the simulation for FalconCore objects.
			@return void
		*/
		void simulate();

		/**
			@brief Tests if the FalconCore meets all the requirements for a successful launch. 
			The requirements:
				- the cost must be >0
				- it must have a capsuleType
				- it must have a rocketType
			@return void
		*/
		void test();
};

#endif
