#include "Falcon9Simulation.h"

Falcon9Simulation::Falcon9Simulation(Component* c,Component* r, SimulationState* s) : Simulation(c, r, s){

}

void Falcon9Simulation::tweakSimulation() {
	// TODO - implement Falcon9Simulation::tweakSimulation
	throw "Not yet implemented";
}
