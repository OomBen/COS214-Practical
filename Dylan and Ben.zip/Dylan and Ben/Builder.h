/**
	@file Builder.h
	@brief Describes the methods to build the components of a rocket.
	@author The 6 Muskateers
*/

#ifndef BUILDER_H
#define BUILDER_H

#include <iostream>
#include <string>
#include "Component.h"
#include "Simulation.h"

using namespace std;
class Builder 
{
	public:
		/**
			@brief Pure virtual function to be implemented in children classes.
				The function builds a Falcon9 Core for the rocket.			
			@return void
		*/
		virtual void buildFalcon9() = 0;

		/**
			@brief Pure virtual function to be implemented in children classes.
				The function builds a FalconHeavy Core for the rocket.
				@return void
		*/
		virtual void buildFalconHeavy() = 0;

		/**
			@brief Pure virtual function to be implemented in children classes.
				The function constructs a capsule for the rocket.
			@return void
		*/
		virtual void constructCapsule(string type) = 0;

		
		/**
			@brief Pure virtual function to be implemented in children classes.
				The function returns the current spacecraft.
			@return Component*
		*/
		virtual Component*  getSpacecraft() = 0;

		/**
			@brief Pure virtual function to be implemented in children classes.
				The function creates a simulation for the rocket.
			@return Simulation* 
		*/
		virtual Simulation* createSimulation(string type) = 0;
};

#endif
