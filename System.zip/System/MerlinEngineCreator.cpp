/**
	@file MerlinEngineCreator.cpp
	@brief Implementation for MerlinEngineCreator.h
*/

#include "MerlinEngineCreator.h"

Component* MerlinEngineCreator::factoryMethod() 
{
	return new MerlinEngine();
}

