/**
	@file CoreCreator.cpp
	@brief Implementation for Cor.Creatorh
*/

#include "CoreCreator.h"

Component* CoreCreator::factoryMethod() 
{
	return new FalconCore();
}


