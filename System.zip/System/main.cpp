/**
    @file main.cpp
    @brief Runs the program.
*/

// #include "Director.h"
// #include "Builder.h"
// #include "Simulation.h"
// #include "ConcreteRocketBuilder.h"
// #include "Caretaker.h"
#include "Facade.h"

// #include "unitTest.cpp"
// #include <gtest/gtest.h>

#include <stdio.h>
#include <unistd.h> // for usleep function

using namespace std;

int main(int argc, char **argv) {
    // testing::InitGoogleTest(&argc, argv);
    // return RUN_ALL_TESTS();

    Facade* f = new Facade();
    string input = "";
    do{
        f->build();
        bool flag;
        
        do {
            cout<<"Would you like to build a new simulation or use a pre made one?" << endl;
            cout<<"[1]: Build My Own" << endl;
            cout<<"[2]: Pre-made" << endl;
            cout<<"[3]: Restore your most recent rocket" << endl;
            cout<<"[4]: Run all your saved simulations" << endl;
            getline(cin,input);
        } while (input != "1" && input != "2" && input != "3" && input != "4");
        
        int stageCount = 0;
        if(input=="1"){
            do {
                do {
                    cout<<"What would you like stage "<<to_string(stageCount)<<" to do?"<<endl;
                    stageCount++;
                    cout<<"[1]: Static-Fire Test"<< endl;
                    cout<<"[2]: Jettison Fairing"<< endl;
                    cout<<"[3]: Separate Boosters" << endl;
                    cout<<"[4]: Distribute Satellites" << endl;
                    cout<<"[5]: Deliver Crew" << endl;
                    cout<<"[6]: Use Communications Network" << endl;
                    cout<<"[7]: Fire Merlin Engines" << endl;
                    cout<<"[8]: Fire Vacuum Merlin Engines" << endl;

                    bool flag = true;
                    input = "";
                    getline(cin,input);
                    for (int i = 0; i<input.length();i++) {
                        if (isdigit(input.at(i))) {
                            flag=false;
                            break;
                        }
                    }
                    int in;
                    if(!flag){
                        in = stoi(input);
                
                        switch(in){
                            case 1:
                                f->staticFireTest();
                                break;
                            case 2:
                                f->jettisonFairing();
                                break;
                            case 3:
                                f->separateBoosters();
                                break;
                            case 4:
                                f->distributeSatellites();
                                break;
                            case 5:
                                f->deliverCrew();
                                break;
                            case 6:
                                f->useCommNetwork();
                                break;
                            case 7:
                                f->fireMerlin();
                                break;
                            case 8:
                                f->fireVacuumMerlin();
                                break;
                        }
                    }
                }while (flag && stoi(input)>0 && stoi(input)<9);
                do{
                    do{
                        cout<<"What would you like to do with your simulation?" << endl;
                        cout<<"[1]: Add Another Stage"<<endl;
                        cout<<"[2]: Edit Simulation"<<endl;
                        cout<<"[3]: Save Simulation"<<endl;
                        cout<<"[4]: Run Simulation"<<endl;
                        cout<<"[5]: Print Simulation"<<endl;
                        cout<<"[6]: Exit Editor"<<endl;
                        input = "";
                        getline(cin,input);
                    }while (input != "1" && input != "2" && input != "3" && input != "4" && input != "5" && input != "6");
                    
                    if(input == "2"){
                        if(f->editSimulation()){
                            stageCount--;
                        }
                    }
                    else if(input == "3"){
                        f->storeSimulation();
                        cout << "Saved!" << endl;
                    }
                    else if(input == "4"){
                        f->runSimulation();
                    }
                    else if(input == "5"){
                        f->printSimulation();
                    }
                }while (input!="1" && input!="6");
            }while (input == "1");
        }
        else if(input == "2"){
            do{
                cout<<"Would you like to launch your rocket?"<<endl;
                cout<<"[y/n]:";
                input = "";
                getline(cin,input);
            } while (input != "y" && input != "n");
            if(input == "y"){
                f->launch();
            }
        }

        else if(input == "3"){
            f->retrieveSimulation();
        }

        else if(input == "4"){
            f->retrieveAll();
        }

        cout<<"Would you like to make another rocket?"<<endl;
        cout<<"[y/n]:";
        input = "";
        getline(cin,input);
    }while (input == "y");
    return 0;
}