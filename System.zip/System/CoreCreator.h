/**
	@file CoreCreator.h
	@brief 
	Participant - Concrete Creator (Factory Method), ConcretePrototype (Prototype).
	Defines the methods and attributes of the class that builds FalconCore engines.
	@author The 6 Musketeers
*/

#ifndef CORECREATOR_H
#define CORECREATOR_H

#include "ComponentCreator.h"
#include "Component.h"
#include "FalconCore.h"

//Factory Method Concrete Creator
class CoreCreator : public ComponentCreator 
{
	public:
		/**
			@brief Factory method to create a new FalconCore object.
			@return Component* 
		*/
		Component* factoryMethod();

		//Component* clone(Component* C);
};

#endif
