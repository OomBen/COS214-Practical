/**
	@file RocketCapsule.cpp
	@brief Implementation for RocketCapsule.h
*/

#include "RocketCapsule.h"
#include "CapsuleOffline.h"

RocketCapsule::RocketCapsule(Component* r): Component(0)
{
	rocket = r;
	state = new CapsuleOffline();
}

void RocketCapsule::simulate() 
{
	rocketCost += this->cost;
	cout << "Component Name: RocketCapsule | Status: Nominal | Component Cost:" << this->cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void RocketCapsule::test() 
{

}

void RocketCapsule::addCapsule(Component* r)
{
	//Register this to an existing component
	rocket = r;
}

// CapsuleState* RocketCapsule::getState()
// {
//     return state;
// }

void RocketCapsule::setState(CapsuleState* s){
	//delete state;
	state = s;
}

double RocketCapsule::getPayloadWeight() 
{
	return payloadWeight;
}

void RocketCapsule::setPayloadWeight(double pw) 
{
	payloadWeight = pw;
}

void RocketCapsule::requestStateChange()
{
	setState(state->handleChange());
}

Satellite* RocketCapsule::getSatellite(int id){
	cout << "No satellites in this capsule type." << endl;
	return NULL;
}

CapsuleState* RocketCapsule::getState(){
	return state;
}