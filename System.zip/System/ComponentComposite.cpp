/**
	@file ComponentComposite.cpp
	@brief Implementation for ComponentComposite.h
*/

#include "ComponentComposite.h"

ComponentComposite::ComponentComposite(): Component(0.0){
	
}

void ComponentComposite::simulate() {
	for (auto c: components){
		c -> simulate();
	}
}

void ComponentComposite::test() {
	for (auto c: components){
		c -> test();
	}
}

void ComponentComposite::add(Component* c) {
	cost += c -> getCost();
	components.push_back(c);
}

void ComponentComposite::remove(int pos) {
	int i=0;
	vector<Component*>::iterator it = components.begin();
	while ((it != components.end())&&i<pos) {
		if (i==pos) {
			components.erase(it);
		}
		++it;
		i++;
	}
}

Component* ComponentComposite::getComponent(int pos) {
	return components[pos];
}

void ComponentComposite::separate() {
	int count = 0;
	for (auto &core : components) // access by reference to avoid copying
	{
		cout << "Core " << to_string(count++) << ": ";
		core->separate();
	}
}

void ComponentComposite::fireMerlin(){
	int count = 0;
	for (auto &merlin : components) // access by reference to avoid copying
	{
		cout << "Merlin Engine " << to_string(count++) << ": ";
		merlin->fireMerlin();
	}
}

void ComponentComposite::land() {
	int count = 0;
	for (auto &core : components) // access by reference to avoid copying
	{
		cout << "Core " << to_string(count++) << ": ";
		core->land();
	}
}

int ComponentComposite::getSize() {
	return components.size();
}