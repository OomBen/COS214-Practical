/**
	@file MerlinEngine.cpp
	@brief Implementation for MerlinEngine.h
*/

#include "MerlinEngine.h"

MerlinEngine::MerlinEngine(): Component(300000.0)
{

}

void MerlinEngine::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Merlin Engine | Status: Firing up | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void MerlinEngine::test() 
{
	cout<<"Merlin engine warmed up without failure"<<endl;
}

void MerlinEngine::fireMerlin(){
	cout << "Merlin engine ignites successfully" << endl;
}
