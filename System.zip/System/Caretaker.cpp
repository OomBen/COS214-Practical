/**
	@file Caretaker.cpp
	@brief Implementation for Caretaker.h
*/

#include "Caretaker.h"

Caretaker::Caretaker() {
}

Caretaker::~Caretaker(){
	// if(store != NULL){
	// 	delete store;
	// }
	store.clear() ;
}

void Caretaker::storeMemento(Memento* m) {
	store.push_back(m);
}

Memento* Caretaker::retrieveMemento() {
	Memento* m = store.front();
	store.erase(store.begin());
	return m;
}

int Caretaker::getSize(){
	return store.size();
}
