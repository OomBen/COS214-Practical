/**
	@file User.h
	@brief	
		Participant - Concrete Observer (Observer)
		Describes the attributes and methods of class that observes the state of Satellite objects.
	@author The 6 Musketeers
*/

#ifndef USER_H
#define USER_H

#include "Observer.h"
#include "SatelliteState.h"
#include "StarlinkSatellite.h"

static int IDcounter = 0;

class User : public Observer 
{
	private:
		SatelliteState* satelliteState; /**< The state of the Satellite it's observing. */
		Satellite* subject; /**< The Satellite that it's observing.*/
		int ID;

	public:
		/**
			@brief Constructor for User objects.
			Sets the subject variable to the StarlinkSatellite passed in as a parameter.
			@param s StarlinkSatellite* - the StarlinkSatellite to set to.
		*/
		User(Satellite* s);

		/**
			@brief Updates the satelliteState variable.
			@return void
		*/
		void update(int satelliteID, string status);
};

#endif
