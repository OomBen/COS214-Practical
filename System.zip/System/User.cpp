/**
	@file User.cpp
	@brief Implementation for User.h
*/

#include "User.h"

User::User(Satellite* s)
{
	ID = IDcounter;
	IDcounter++;
	subject = s;
	s->attach(this);
}

void User::update(int satelliteID, string status) {
	cout << "User " << to_string(ID) << " has received Satellite " << to_string(satelliteID) << "'s status change to " << status << endl;
}
