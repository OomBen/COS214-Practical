/**
	@file Facade.cpp
	@brief Implementation for Facade.h
*/

#include "Facade.h"
#include "ConcreteRocketBuilder.h"
#include "Director.h"
#include "Caretaker.h"

static Caretaker store;

Facade::Facade()
{
    simulation = NULL;
}

Facade::~Facade()
{
    if (simulation != NULL)
    {
        delete simulation;
    }
    if (rocket != NULL)
    {
        delete rocket;
    }
}

void Facade::launch()
{
    test();
    //would you like to tweak
    //retest if tweaked
    simulation->launch();
}

void Facade::test()
{
    simulation->staticFireTest();
}

void Facade::build()
{
    cout << "==============================================" << endl;
    Builder *build = new ConcreteRocketBuilder();
    Director *direct = new Director(build);
    Simulation *simulate;

    rocket = direct->construct();

    //would you like to test
    //would you like to tweak
    //retest if tweaked

    simulation = direct->createSimulation();

    //delete direct;
}

void Facade::storeSimulation()
{
    store.storeMemento(simulation->createMemento());
}

void Facade::retrieveSimulation()
{
    if (store.getSize() != 0)
    {
        SimulationState *state = store.retrieveMemento()->getState();
        ConcreteRocketBuilder *rocketBuilder = new ConcreteRocketBuilder();
        if (state->getRocketType() == "Falcon9")
        {
            rocketBuilder->buildFalcon9();
            rocket = rocketBuilder->getSpacecraft();
        }
        else
        {
            rocketBuilder->buildFalconHeavy();
            rocket = rocketBuilder->getSpacecraft();
        }

        RocketCapsule *capsule;
        if (state->getCapsuleType() == "Crew Dragon")
        {
            capsule = new CrewDragon(rocket);
            capsule->setPassengers(state->getPassengers());
        }
        else if (state->getCapsuleType() == "Cargo Dragon")
        {
            capsule = new CargoDragon(rocket);
        }
        else if (state->getCapsuleType() == "Fairing")
        {
            capsule = new Fairing(rocket);
            capsule->setSatellites(state->getSatellites());
        }

        simulation = new Simulation(capsule, rocket, state);
        simulation->setMethodCalls(state->getMethodCalls());
        //simulation->runSimulation();
    }
    else
    {
        cout << "You do not have any saved simulations." << endl;
    }
}

void Facade::separateBoosters()
{
    simulation->separateBoosters();
}

void Facade::useCommNetwork()
{
    int id;
    SatelliteState *state;
    if (simulation->getState()->getCapsuleType() == "Fairing")
    {
        cout << "How would you like to use the Satellite Communication Network?\n[1]: Send A Message To A Satellite \n[2]: Change Satellite State\n"
             << endl;

        string input = "";
        getline(cin, input);
        if (input == "1")
        {
            cout << "Input Receiver ID: ";
            input == "";
            getline(cin, input);
            int receiver = stoi(input);

            cout << "Input Sender ID: ";
            input == "";
            getline(cin, input);
            int sender = stoi(input);

            cout << "Input Message: ";
            input == "";
            getline(cin, input);
            string msg = input;

            simulation->sendMessage(sender, receiver, msg);
        }
        else if (input == "2")
        {
            do
            {
                cout << "Provide the ID of the satellite for which you wish to alter status: ";
                input == "";
                getline(cin, input);
                int id = stoi(input);

                cout << "Select a new status:\n[1]Broadcasting\n[2]Online\n[3]Offline" << endl;
                input == "";
                getline(cin, input);

                RocketCapsule *capsule = simulation->getCapsule();
                if (input == "1")
                {
                    state = new Broadcasting();
                }
                else if (input == "2")
                {
                    state = new Online();
                }
                else if (input == "3")
                {
                    state = new Offline();
                }
                simulation->changeSatelliteState(id, state);
            } while (input != "1" && input != "2" && input != "3");
        }

        cout << "\nContinue using the Satellite Communication Network?\n[1]Yes\n[2]No" << endl;
        input = "";
        getline(cin, input);
        if (input == "1")
        {
            useCommNetwork();
        }
    }
    else
    {
        cout << "Capsule cannot use Communications Network. Capsule is not a Fairing." << endl;
    }
}

Component *Facade::getRocket()
{
    return rocket;
}

void Facade::fireMerlin()
{
    simulation->fireMerlin();
}

void Facade::fireVacuumMerlin()
{
    simulation->fireVacuumMerlin();
}

void Facade::runSimulation()
{
    simulation->updateSimulationState();
    simulation->runSimulation();
}

void Facade::deliverCrew()
{
    simulation->deliverCrew();
}

void Facade::distributeSatellites()
{
    simulation->distributeSatellites();
}

void Facade::staticFireTest()
{
    simulation->staticFireTest();
}

void Facade::jettisonFairing()
{
    simulation->jettisonFairing();
}

void Facade::printSimulation()
{
    simulation->printSimulation();
}

bool Facade::editSimulation()
{
    string input, param_1, param_2 = "";
    bool flag = true;
    int max = simulation->getSimulationSize();
    do
    {
        cout << "How would you like to edit your simulation?" << endl;
        cout << "[1]: Swap Staging Order" << endl;
        cout << "[2]: Remove Stage" << endl;
        cout << "[3]: Print Simulation" << endl;

        input = "";
        getline(cin, input);
    } while (input != "1" && input != "2" && input != "3");

    if (input == "1")
    {
        if (max==1) {
            cout<<"Cannot swap stages when you only have one stage"<<endl;
        } else {
            do
            {
                flag = true;
                cout << "Which stages would you like to swap?" << endl;
                cout << "Swap stage:" << endl;
                getline(cin, param_1);
                cout << "With stage:" << endl;
                getline(cin, param_2);

                for (int i = 0; i < param_1.length(); i++)
                {
                    if (!isdigit(param_1.at(i)))
                    {
                        flag = false;
                        break;
                    }
                }

                for (int i = 0; i < param_2.length(); i++)
                {
                    if (!isdigit(param_2.at(i)))
                    {
                        flag = false;
                        break;
                    }
                }
                int stage1=-1;
                int stage2=-1;

                if (flag) {
                    stage1 = stoi(param_1);
                    stage2=stoi(param_2);
                    if (stage1<0||stage1>=max||stage2<0||stage2>=max) {
                        flag = false;
                    }
                }  

            } while (!flag);
            simulation->swapStage(stoi(param_1), stoi(param_2));
            return true;
        }
    }
    else if (input == "2")
    {
        int in;
        flag = true;
        do
        {
            flag = true;
            int in=-1;

            cout << "Which stage number would you like to remove?" << endl;
            input = "";
            getline(cin, input);
            for (int i = 0; i < input.length(); i++)
            {
                if (!isdigit(input.at(i)))
                {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                in = stoi(input);
                if (in<0||in>=max) {
                    flag = false;
                }
            }
        } while (!flag);
        simulation->removeStage(in);
    }
    else if (input == "3")
    {
        simulation->printSimulation();
    }
    return false;
}

void Facade::retrieveAll()
{
    if (store.getSize() != 0)
    {
        for (int i = 0; i < store.getSize(); i++)
        {
            retrieveSimulation();
        }
    }
    else
    {
        cout << "You do not have any saved simulations." << endl;
    }
}