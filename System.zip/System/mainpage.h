
/** @mainpage 
*
* @authors The 6 Musketeers
*
* @section intro COS214 Group Project
* This is the documentation for the COS214 Project 2021.
*
* <hr>
* @section members Group Members
* u20632429 - Chiara Goncalves
*	u20444738 - Zoe Liebenberg
*	u20438151 - Jade Peche
*	u17030553 - Ben Pietersen
*	u20498510 - Dylan Pietersen
*	u20430516 - Steven Schormann
*/