/**
	@file Online.cpp
	@brief Implementation for Online.h
*/

#include "Online.h"
#include "Broadcasting.h"

Online::Online(){}

string Online::getType() {
	return "Online";
}

SatelliteState* Online::handleChange(){
	return new Broadcasting();
}