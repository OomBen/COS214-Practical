/**
	@file MerlinEngineCreator.h
	@brief 
	Participant - ConcreteCreator (Factory Method), ConcretePrototype (Prototype)
	Defines the methods of the class that creates MerlinEngine objects.
	@author The 6 Musketeers
*/


#ifndef MERLINENGINECREATOR_H
#define MERLINENGINECREATOR_H

#include "ComponentCreator.h"
#include "Component.h"
#include "MerlinEngine.h"

class MerlinEngineCreator : public ComponentCreator 
{
	public:
		/**
			@brief Factory method to create a MerlinEngine.
			@return Component*
		*/
		Component* factoryMethod();

		
		//Component* clone(Component* C);
};

#endif
