/**
	@file SatelliteCreator.h
	@brief 
		Participant - Creator (Factory Method).
		Describes the properties and methods the abstract class that creates a Satellite.
	@author The 6 Musketeers
*/

#ifndef SATELLITECREATOR_H
#define SATELLITECREATOR_H

#include <iostream>
#include <string>

#include "StarlinkSatellite.h"

using namespace std;

class SatelliteCreator 
{
	private:
		int count;	/**< The amount of Satellite objects created.*/

	public:
		/**
			@brief Constructor for the SatelliteCreator objects.
			Sets count to 0.
		*/
		SatelliteCreator();

		/**
			@brief Pure virtual function to be implemented in children classes.
			Factory method to create Satellite objects.
			@return Satellite*
		*/
		virtual Satellite* factoryMethod()=0;

		/**
			@brief Pure virtual function to be implemented in children classes.
			Sets the count variable to the integer passed in as a parameter.
			@param id int - the number to be set to.
			@return void
		*/
		virtual void setIDCount(int id) = 0;
};

#endif
