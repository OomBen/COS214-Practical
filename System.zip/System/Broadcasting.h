/**
	@file Broadcasting.h
	@brief 
		Participant - Concrete State (State).
		Describes the properties and methods of a Satellite in the 'broadcasting' state.
	@author The 6 Musketeers
*/


#ifndef BROADCASTING_H
#define BROADCASTING_H

#include "SatelliteState.h"

using namespace std;
class Satellite;
class Broadcasting : public SatelliteState 
{
	public:
		/**
			@brief Constructor for the Broadcasting object.
		*/
		Broadcasting();

		/**
			@brief Returns the type of state the satellite is currently in (Broadcasting).
			@return string
		*/
		string getType();

		/**
			@brief Handles a change in state - sets the current state of the satellite to offline.
			@return SatelliteState*
		*/
		SatelliteState* handleChange();
};

#endif
