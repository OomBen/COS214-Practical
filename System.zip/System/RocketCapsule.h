/**
	@file RocketCapsule.h
	@brief 
		Participant - Decorator (Decorator), Context (State)
		Describes the properties and methods of a RocketCapule that can be added to a rocket Component.
	@author The 6 Musketeers
*/

#ifndef ROCKETCAPSULE_H
#define ROCKETCAPSULE_H

#include <vector>

#include "Component.h"
#include "CapsuleState.h"
#include "Satellite.h"

class CapsuleState;

class RocketCapsule : public Component 
{
	protected:
		string capsuleType; /**< The type of capsule (CrewDragon, CargoDragon, Fairing). */
		CapsuleState* state; /**< The state of the capsule (Docked, Arrriving, Departing, Offline).*/

	private:
		Component* rocket; /**< The rocket that the capsule is added to. */
		double payloadWeight; /**< The weight of the capsule.*/
		
	public:
		/**
			@brief Constructor for RocketCapsule objects.
			Sets the rocket variable to the Component sent in as a parameter. 
			Sets the state to CapsuleOffline.
		*/
		RocketCapsule(Component* r);

		/**
			@brief Pure virtual function to be implemented in all the children classes.
			Starts the simulation for RocketCapsule objects.
			@return void
		*/
		virtual void simulate() = 0;

		/**
			@brief Tests if the RocketCapsule meets all the requirements for a successful launch. 
			The requirements:
				- the cost must be >0
				- it must have a capsuleType
				- it must have a rocketType
			@return void
		*/
		virtual void test() = 0;

		/**
			@brief Adds a capsule to the rocket.
			@param r Component* - the rocket to be added to.
			@return void
		*/
		void addCapsule(Component* r);

		/**
			@brief Requests a state change of the RocketCapsule. 
			Calls the handleChange method on the CapsuleState object.
			@return void
		*/
		void requestStateChange();

		/**
			@brief Sets the state of the RocketCapsule to the CapsuleState passed in as a parameter.
			@param s CapsuleState* - the state to be set to.
			@return void
		*/
		void setState(CapsuleState* s);

		/**
			@brief Getter function to return the payloadWeight of the RocketCapsule.
			@return double
		*/
		double getPayloadWeight();

		/**
			@brief Setter function to set the payloadWeight of the RocketCapsule to the value passed in as a parameter.
			@param pw double - the value to be set to.
		*/
		void setPayloadWeight(double pw);

		/**
			@brief Virtual setter function to set the vector of passengers in a CrewDragon RocketCapsule.
			Only implemented in the CrewDragon class.
			@param p vector<string> - the string vector containing the names of all the passengers.
			@return void
		*/
		virtual void setPassengers(vector<string> p){};

		/**
			@brief Virtual setter function to set the vector of satellites in a Fairing RocketCapsule.
			Only implemented in the Fairing class.
			@param s vector<Satellite*> - vector of all the Satellite objects in the Fairing.
			@return void
		*/
		virtual void setSatellites(vector<Satellite*> s){};

		/**
	 		@brief Get a specific Satellite object on board the Fairing
			@return Satellite* 
		*/
		virtual Satellite* getSatellite(int id);

		/**
	 		@brief Get the CapsuleState object
			@return CapsuleState* 
		*/
		CapsuleState* getState();
};

#endif
