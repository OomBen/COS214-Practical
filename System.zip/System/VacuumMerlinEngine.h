/**
	@file VacuumMerlinEngine.h
	@brief	
		Participant - Concrete Product (Factory Method)
		Describes the attributes and methods of a VacuumMerlinEngine object.
	@author The 6 Musketeers
*/


#ifndef VACUUMMERLINENGINE_H
#define VACUUMMERLINENGINE_H

#include "Component.h"

class VacuumMerlinEngine : public Component
{
	public:
		/**
			@brief Constructor for VacuumMerlinEngine objects.
			Calls the Component constructor the initialize the attributes.
		*/
		VacuumMerlinEngine();

		/**
			@brief Starts the simulation for VacuumMerlinEngine objects.
			@return void
		*/
		void simulate();

		/**
			@brief Tests if the MerlinEngine meets all the requirements for a successful launch. 
			The requirements:
				- the cost must be >0
				- it must have a capsuleType
				- it must have a rocketType
			@return void
		*/
		void test();

		/**
			@brief Outputs that a VacuumMerlin object has been ignited.
			@return void
		*/
		void fireVacuumMerlin();
};

#endif
