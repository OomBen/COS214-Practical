/**
	@file Fairing.cpp
	@brief Implementation for Fairing.h
*/

#include "Fairing.h"

Fairing::Fairing(Component* r): RocketCapsule(r)
{
	this->capsuleType = "Fairing";
}

void Fairing::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Fairing | Status: " << state->getState() << " | Satellites: " << getSatellites().size() << " | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl; 

	//need to do spreading out and add calls with mediator and observer
	
	// satellites[0]->requestStateChange();
	// cout << "Satellites are " << satellites[0]->getState();

}

void Fairing::test() 
{
	cout<<"Fairing is opperating normally"<<endl;
}

vector<Satellite*> Fairing::getSatellites() 
{
	return satellites;
}

//not right yet
void Fairing::setSatellites(vector<Satellite*> s) {
	this->satellites = s;
}

Satellite* Fairing::getSatellite(int id){
	return satellites[id];
}
