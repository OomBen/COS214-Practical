/**
	@file Simulation.h
	@brief	
		Participant - Abstraction (Bridge)
		Describes the abstract class for running a simulation of a rocket launch.
	@author The 6 Musketeers
*/

#ifndef SIMULATION_H
#define SIMULATION_H

#include "SimulationState.h"
#include "Component.h"
#include "Fairing.h"
#include "Memento.h"
#include "Satellite.h"
#include "SatelliteState.h"
#include "CapsuleArriving.h"
#include "CapsuleDeparting.h"
#include <cstring>
#include <vector>

class Simulation {

private:
	SimulationState* simulationState;	/**< The state of the Simulation. */
	Component* rocket;	/**< The rocket on which the Simulation is performed.*/
	RocketCapsule* capsule;	/**< The capsule on the rocket on which the Simulation is performed. */
	vector<string> methodCalls; /**< Vector of the method calls on the rocket in the simulation. */

public:
	/**
		@brief Constructor for Simulation objects. 
		Sets the simulationState, rocket and capsule variables.
		@param c Component* - The capsule on the rocket on which the Simulation is performed.
		@param r Component* - The rocket on which the Simulation is performed.
		@param s SimulationState* - The state of the Simulation.
	*/
	Simulation(RocketCapsule* c,Component* r, SimulationState* s);

	RocketCapsule* getCapsule();

	/**
		@brief Creates a Memento object and sets the state of the memento to the current simulationState.
		@return Memento*
	*/
	Memento* createMemento();

	/**
		@brief Sets the simulationState to the state of the memento.
		@param m Memento* - the Memento object storing the current simulation.
		@return void
	*/
	void restoreMemento(Memento* m);

	/**
		@brief Adds a call to the simulationState and calls the test() method on the rocket.
		@return void
	*/
	void staticFireTest();

	/**
		@brief Launches the rocket.
		IF FALCON9 ROCKET-
			-- Stage 1: single falcon 9 core with 9 Merlin engines
			-- Stage 2: single vacuum Merlin engine 
		IF FALCONHEAVY ROCKET-
			-- Stage 1: 3 Falcon Heavy cores with 27 Merlin engines
			-- Stage 2: single Merlin engine
		@return void
	*/
	void launch();

	/**
		@brief Pure virtual method to be implemented in all children classes.
		Tweaks the simulation on the rocket to represent a more realistic example of a real-world rocket simulation.
		@return void
	*/
	//virtual void tweakSimulation() = 0;

	/**
		@brief Prints a visual representation of the Simulation method calls.
		@return void
	*/
	void printSimulation();

	/**
	 	@brief Delivers Fairing capsule's payload (if Fairing is attached).
	 	@return void
	 */
	void jettisonFairing();

	/**
	 	@brief Seperates boosters from the rocket.
	 	@return void
	 */
	void separateBoosters();

	/**
	 	@brief Distributes satellites once in low-earth orbit.
	 	@return void
	 */
	void distributeSatellites();

	/**
	 	@brief Delivers crew once in low-earth orbit.
	 	@return void
	 */
	void deliverCrew();

	/**
	 	@brief Sends a string message from the receiving satellite to a receiving satellite.
	 	@return void
	 */
	void sendMessage(int sender,int reciever,string message);

	/**
		@brief Runs various launch methods from the simulationState consecutively in order to simulate launch event.
		@return void
	*/
	void runSimulation();

	/**
		@brief Returns the state of te Simulation.
		@return SimulationState*
	*/
	SimulationState* getState();

	/**
		@brief Outputs that a MerlinEngine has been ignited.
		@return void
	*/
	void fireMerlin();

	/**
		@brief Outputs that the boosters have landed.
		@return void
	*/
	void landBoosters();

	/**
		@brief Outputs that a VacuumMerlinEngine has been ignited.
		@return void
	*/
	void fireVacuumMerlin();

	/**
		@brief Changes the state of the Satellite with an id of the int passed in as a parameter to the state passed in as a parameter.
		@param id int - the id of the Satellite of which we need to change the state.
		@param state SatelliteState* - the state to change to.
	*/
	void changeSatelliteState(int id, SatelliteState* state);

	/**
		@brief Adds a call to vector of methodCalls.
		@param c string - the method call to add to the vector.
		@return void
	*/
	void addCall(string c);

	/**
		@brief Checks if the methodCall vector contains the string passed in as a parameter.
		Returns true if it contains it. Returns false if it doesn't contain it.
		@param c string - the method call to check for.
		@return bool
	*/
	bool containsCall(string c);

	void updateSimulationState();

	void swapStage(int pos_1, int pos_2);

	void removeStage(int pos);

	int getSimulationSize();
};

#endif
