/**
	@file ConcreteRocketBuilder.h
	@brief 
	Participant - Concrete Builder (Builder)
	Defines the methods and attributes of the class that builds a rocket.
	@author The 6 Musketeers
*/

#ifndef CONCRETEROCKETBUILDER_H
#define CONCRETEROCKETBUILDER_H

#include "Component.h"
#include "Builder.h"
#include "ComponentCreator.h"
#include "CoreCreator.h"
#include "VacuumMerlinEngineCreator.h"
#include "MerlinEngineCreator.h"
#include "ComponentComposite.h"
#include "RocketCapsule.h"
#include "CrewDragon.h"
#include "CargoDragon.h"
#include "Fairing.h"
#include "SimulationState.h"
#include "SatelliteCreator.h"
#include "StarlinkCreator.h"
#include "User.h"

#include "Simulation.h"

#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

class ConcreteRocketBuilder : public Builder 
{
	private:
		ComponentCreator* merlinCreator; /**< ComponentCreator for MerlinEngine objects. */
		ComponentCreator* vacuumMerlinCreator; /**< ComponentCreator for VacuumMerlinEngine objects.*/
		ComponentCreator* coreCreator; /**< ComponentCreator for FalconCore objects. */
		SatelliteCreator* starlinkCreator; /**< ComponentCreator for StarlinkSatellite objects. */
		Component* rocket;	/**< Component object for the rocket */
		RocketCapsule* capsule; /**< RocketCapsule object for the capsule */
		SimulationState* simulationState; /**< SimulationState object for the simulation state of the rocket*/

	public:
		/**
			@brief Constructor for ConcreteRocketBuilder objects.
		*/
		ConcreteRocketBuilder();

		/**
			@brief Returns the current spacecraft/rocket.
			@return Component*
		*/
		Component* getSpacecraft();

		/**
			@brief Returns the current RocketCapsule object.
			@return RocketCapsule*
		*/
		RocketCapsule* getCapsule();

		/**
			@brief Builds the Falcon9 rocket. 
			Adds the FalconCore, MerlinEngine and VacuumMerlinEngine components.
			@return void
		*/
		void buildFalcon9();

		/**
			@brief Builds the FalconHeavy rocket.
			Adds the FalconCore, MerlinEngine and VacuumMerlinEngine components.
			@return void
		*/
		void buildFalconHeavy();

		/**
			@brief Creates a new capsule. 
			The capsule can be either a CrewDragon, CargoDragon or Fairing. 
			The capsule is constructed differently based on the capsule type.
			@param type string - the type of capsule.
			@return void
		*/
		void constructCapsule(string type);

		/**
			@brief Creates a new simulation based on the capsule, rocket and simulation state.
			@return Simulation*
		*/
		Simulation* createSimulation();
};

#endif
