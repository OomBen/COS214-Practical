/**
	@file Mediator.h
	@brief 
	Participant - Mediator (Mediator)
	Defines the methods of the interface that enables communication between the different satellites.
	@author The 6 Musketeers
*/


#ifndef MEDIATOR_H
#define MEDIATOR_H

#include <string>
#include <iostream>

#include "Satellite.h"
class Satellite;
using namespace std;

class Mediator {

private:
	/**
		@brief Pure virtual function to be implemented in all children.
		Notifies all the satellites (colleagues) if the state of the one of the satellites have changed.
		@param colleague Satellite* - the Satellite object that has changed states.
		@return void
	*/
public:
	/**
		@brief Pure virtual function to be implemented in all children.
		Notifies all the satellites (colleagues) if the state of the one of the satellites have changed.
		@param colleague Satellite* - the Satellite object that has changed states.
		@return void
	*/
	virtual void notify(int sender) = 0;

	/**
		@brief Sends a string message to a particular satellite.
		@param sender The ID of the sender.
		@param receiver The ID of the receiver
		@param msg The message to send
		@return void
	*/
	virtual void sendMessage(int sender, int receiver, string msg) = 0;
};

#endif
