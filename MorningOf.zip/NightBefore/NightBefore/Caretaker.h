
/**
	@file Caretaker.h
	@brief	
		Participant - Caretaker (Memento)
		Describes the class responsible for the safekeeping of the Memento class' state.
	@author The 6 Musketeers
*/


#ifndef CARETAKER_H
#define CARETAKER_H

#include <string>
#include <iostream>
#include <vector>

#include "Memento.h"

using namespace std;

class Caretaker {

private:
	vector<Memento*> store;	/**< Memento object that stores the current state of the rocket*/

public:

	/**
		@brief Constructor for Caretaker objects. 
		Sets the store to NULL.
	*/
	Caretaker();

	/**
		@brief Destructor for Caretaker objects. 
		Deletes the store object and the memory allocated to it.
	*/
	~Caretaker();

	/**
		@brief Stores the current state of the rocket.
		@param m Memento* - the Memento storing the current state of the rocket.
		@return void
	*/
	void storeMemento(Memento* m);

	/**
		@brief Returns the current state of the rocket .
		@return Memento*
	*/
	Memento* retrieveMemento();

	int getSize();
};

#endif