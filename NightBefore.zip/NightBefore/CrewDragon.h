/**
	@file CrewDragon.h
	@brief 
	Participant - Concrete Decorator (Decorator)
	Defines the attributes and methods for a Capsule carrying crew members.
	@author The 6 Musketeers
*/

#ifndef CREWDRAGON_H
#define CREWDRAGON_H

#include "RocketCapsule.h"

#include <vector>

class CrewDragon : public RocketCapsule 
{
	private:
		vector<string> passengers; /**< A vector of strings representing the passengers in the capsule.*/

	public:
		/**
			@brief Constructor for CrewDragon objects that takes in a rocket (Component) as a parameter and uses the RocketCapsule (parent) constructor to initialize the rocket object.
			@param r Component* - the rocket to which the CrewDragon object needs to be added to.
		*/
		CrewDragon(Component* r);

		/**
			@brief Starts the simulation for CrewDragon objects.
			@return void
		*/
		void simulate();

		/**
			@brief Tests if the CrewDragon meets all the requirements for a successful launch. 
			The requirements:
				- the cost must be >0
				- it must have a capsuleType
				- it must have a rocketType
			@return void
		*/
		void test();

		/**
			@brief Returns the vector of passsengers.
			@return vector<string>
		*/
		vector<string> getPassengers();

		/**
			@brief Sets the vector of passengers to the vector passed in as a parameter.
			@param p vector<string> - the vector of passengers to set to.
			@return void
		*/
		void setPassengers(vector<string> p);
};

#endif
