/**
	@file ComponentComposite.h
	@brief 
	Participant - Handler (Chain of Responsibility)
	Defines an interface to handle the requests and implementatins of the Falcon9 and FalconHeavy components 
	@author The 6 Muskateers
*/

#ifndef COMPONENTCOMPOSITE_H
#define COMPONENTCOMPOSITE_H

#include "Component.h"
#include <vector>

class ComponentComposite : public Component 
{
	private:
		vector<Component*> components;/**< A vector of Component objects */

	public:
		/**
			@brief Constructor for ComponentComposite objects.
		*/
		ComponentComposite();

		/**
			@brief Starts the simulation for ComponentComposite objects.
			@return void
		*/
		void simulate();

		/**
			@brief Tests if the ComponentComposite meets all the requirements for a successful launch. 
			The requirements depend on the type of Component.
			@return void
		*/
		void test();

		/**
			@brief Virtual function that adds a component to the rocket.
			@param c Component* - the Component to be added to the rocket.
			@return void
		*/
		virtual void add(Component* c);

		/**
			@brief Virtual function the removes a component from the rocket based on its position.
			@param pos int - the position of the Componenet in the vector of components.
			@return void
		*/
		virtual void remove(int pos);

		/**
			@brief Returns a component of the rocket based on its position.
			@param pos int - the position of the Componenet in the vector of components.
			@return Component*
		*/
		Component* getComponent(int pos);

		/**
			@brief Returns the size of the ComponentComposite object.
			@return int
		*/
		int getSize();

		/**
			@brief Seperates the ComponentComposite from the rocket.
			@return void 
		*/
		void separate();

		/** 
			@brief Ignites the MerlinEngine object.
			@return void
		*/
		void fireMerlin();

		/**
			@brief Lands the rocket.
			@return void
		*/
		void land();
};

#endif
