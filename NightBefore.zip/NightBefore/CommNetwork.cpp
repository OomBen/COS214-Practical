/**
	@file CommNetwork.cpp
	@brief Implementation for CommNetwork.h
*/

#include "CommNetwork.h"
#include <iterator>

CommNetwork::CommNetwork(vector<Satellite*> satellites){
	for(auto& s : satellites){
		s->setMediator(this);
	}
	colleagueList = satellites;
}

void CommNetwork::notify(int sender) 
{
	cout << "Satellite " << to_string(sender) << ": changed state to " << colleagueList[sender]->getState()->getType() << endl;
	cout << " Notifying other satellites of this change: ";
	int count = 0;
	for (auto& satty : colleagueList)
	{
		if(satty->getState()->getType()!="offline"){
			cout<<"+";
			count++;
		}
		else{
			cout<<"-";
		}
	}
	cout << endl << to_string(count) << " out of "<< to_string(colleagueList.size()) << " satellites were notified of the change" << endl;
}

void CommNetwork::sendMessage(int sender, int receiver, string msg){
	if(receiver >= colleagueList.size() || receiver < 0){
		cout << "The satellite with ID: " << receiver << " does not exist." << endl;
	}
	else{
		colleagueList[receiver]->receiveMessage(sender, msg);
	}
}