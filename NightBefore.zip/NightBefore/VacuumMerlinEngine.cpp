/**
	@file VacuumMerlinEngine.cpp
	@brief Implementation for VacuumMerlinEngine.h
*/

#include "VacuumMerlinEngine.h"

VacuumMerlinEngine::VacuumMerlinEngine(): Component(400000.0)
{

}

void VacuumMerlinEngine::simulate() {
	rocketCost += cost;
	cout << "Component Name: Vacuum Merlin Engine | Status: Firing up | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void VacuumMerlinEngine::test() 
{
	
}

void VacuumMerlinEngine::fireVacuumMerlin() 
{
	cout << "Vacuum Merlin engine ignites successfully" << endl;
}
