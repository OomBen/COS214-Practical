/**
	@file Facade.h
	@brief 
	Participant - Facade (Facade)
	Delegates client requests to appropriate subsystem objects.
	@author The 6 Musketeers
*/

#ifndef FACADE_H
#define FACADE_H

#include "Simulation.h"
#include "Online.h"
#include "Offline.h"
#include "Broadcasting.h"
#include "RocketCapsule.h"

class Facade 
{
        private:
                Simulation* simulation; /**< The simulation to be run.*/
                Component* rocket; /**< The rocket to be built */
        public:
                /**
                        @brief Constructor for Facade objects.
                */
                Facade();

                /**
                        @brief Destructor for Facade objects.
                */
                ~Facade();

                //Bridge (Simulation) subsystem

                /**
                        @brief Tests and launches the rocket object.
                        @return void 
                */
                void launch();

                /**
                        @brief Tests if the rocket object is ready to launch.
                        Calls the staticFireTest() on the simulation object.
                        @return void
                */
                void test();

                //Builder subsystem
                /**
                        @brief Builds a new rocket object.
                        Creates a new Builder.
                        Creates a new Director.
                        Creates a new Simulation.
                        Calls the construct() method on the Director object to actually create the rocket.
                        Deletes the Director object.
                        @return void
                */
                void build();

                //Memento subsystem

                /**
                        @brief Stores the simulation.
                        Creates a Memento and stores it using storeMemento().
                        @return void
                */
                void storeSimulation();

                /**
                        @brief Sets the simulation variable to the Simulation stored in the Memento object.
                        @return void
                */
                void retrieveSimulation();

                /**
                        @brief Prompts the user with various Communication Network capabilities.
                        @return void
                */
                void useCommNetwork();

                /**
                        @brief Seperates the boosters on the rocket.
                        @return void
                */
                void separateBoosters();

                /** 
                        @brief Returns the current rocket.
                        @return Component*
                */
                Component* getRocket();

                /**
                        @brief Ignites the MerlinEngine objects.
                        @return void.
                */
                void fireMerlin();

                /**
                        @brief Ignites the VacuumMerlinEngine objects.
                */
                void fireVacuumMerlin();

                void runSimulation();

                void deliverCrew();

                void distributeSatellites();

                void staticFireTest();

                void jettisonFairing();

                void printSimulation();

                void editSimulation();
};

#endif