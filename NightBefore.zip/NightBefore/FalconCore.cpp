/**
	@file FalconCore.cpp
	@brief Implementation for FalconCore.h
*/

#include "FalconCore.h"

FalconCore::FalconCore(): Component(30000000.0)
{

}

void FalconCore::simulate() 
{
	rocketCost += cost;
	cout << "Component Name: Falcon Core | Status: Firing up | Component Cost:" << cost << " | Total Rocket Cost: " << rocketCost << endl; 
}

void FalconCore::test() 
{
	
}

void FalconCore::separate(){
	cout << "Falcon core successfully seperated." << endl;
}

void FalconCore::land(){
	cout << "Falcon booster landed successfully.| Money Saved: $32 700 000" << endl;
}
