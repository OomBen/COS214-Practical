/**
	@file Memento.cpp
	@brief Implementation for Memento.h
*/

#include "Memento.h"

SimulationState* Memento::getState() {
	return state;
}

void Memento::setState(SimulationState* c) {
	state = c;
}

Memento::~Memento() {
	if(state != NULL){
		delete state;
	}
}

