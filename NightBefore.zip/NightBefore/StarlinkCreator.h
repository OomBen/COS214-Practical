/**
	@file StarlinkCreator.h
	@brief	
		Participant - Concrete Creator (Factory Method)
		Describes the attributes and methods of the class that creates StarlinkSatellite objects.
	@author The 6 Musketeers
*/

#ifndef STARLINKCREATOR_H
#define STARLINKCREATOR_H

#include "SatelliteCreator.h"
#include "StarlinkSatellite.h"
class StarlinkCreator : public SatelliteCreator 
{
	private:
		int IDcount;	/**< The number of StarlinkCreator objects created.*/

	public:
		/**
			@brief Constructor for StarlinkCreator objects.
			Sets IDcount to zero.
		*/
		StarlinkCreator();

		/**
			@brief Factory method to create StarlinkSatellite objects.
			@return Satellite*
		*/
		Satellite* factoryMethod();

		/**
			@brief Set the current StarlinkSatellite ID counter
		 */
		void setIDCount(int count);
};

#endif