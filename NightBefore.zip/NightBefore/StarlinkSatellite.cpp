/**
	@file StarlinkSatellite.cpp
	@brief Implementation for StarlinkSatellite.h
*/

#include "StarlinkSatellite.h"

StarlinkSatellite::StarlinkSatellite(int ID):Satellite(ID)
{
	//Nothing to do here: Construction logic implemented in parent
}

StarlinkSatellite::StarlinkSatellite(Satellite* s, int id) : Satellite(s->getID()){
	satelliteState = s->getState();
	mediator = s->getMediator();
	observerList = observerList;
	ID = id;
}

SatelliteState* StarlinkSatellite::getState() 
{
	return this->satelliteState;
}

void StarlinkSatellite::setState(SatelliteState* s) 
{
	this->satelliteState = s;
}

Satellite* StarlinkSatellite::clone(int id){
	return new StarlinkSatellite(this, id);
}