/**
	@file CapsuleOffline.cpp
	@brief Implementation for CapsuleOffline.h
*/

#include "CapsuleOffline.h"
#include "CapsuleDeparting.h"

CapsuleOffline::CapsuleOffline(){}

string CapsuleOffline::getState(){
    return "Offline";
}

CapsuleState* CapsuleOffline::handleChange()
{
    return new CapsuleDeparting();
}


